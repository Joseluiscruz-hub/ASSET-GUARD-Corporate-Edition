
import { Component, input, inject, signal, computed, effect } from '@angular/core';
import { CommonModule, DatePipe, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService } from '../../services/data.service';
import { GeminiService } from '../../services/gemini.service';
import { Asset, FailureReport } from '../../types';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

type HistoryTimelineItem = {
  id: string;
  isMaintenance: boolean;
  date: string;
  description: string;
  details: string; // diagnosis or status
  parts: string[];
  type: string;
  cost: number;
  isOpen: boolean;
};

@Component({
  selector: 'app-asset-detail',
  standalone: true,
  imports: [CommonModule, DatePipe, CurrencyPipe, FormsModule],
  template: `
    @if (asset()) {
      <div class="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-gray-200 dark:border-slate-700 overflow-hidden animate-fade-in relative">
        
        <!-- Critical Badge -->
        @if (asset()!.critical) {
           <div class="absolute top-0 right-0 bg-orange-600 text-white text-[10px] uppercase font-black px-4 py-2 rounded-bl-lg z-10 shadow-lg tracking-widest animate-pulse border-l border-b border-orange-700">
             <i class="fas fa-bolt mr-1.5"></i> Activo de Alta Prioridad
           </div>
        }

        <!-- Header -->
        <div class="bg-[#DA291C] text-white p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
             <p class="text-sm font-bold text-red-100 opacity-90 mb-1">COCA-COLA FEMSA</p>
            <div class="flex items-center gap-3">
              <h2 class="text-3xl font-black tracking-tight">{{ asset()!.id }}</h2>
              <span [class]="'px-3 py-1 rounded-md text-[10px] font-black uppercase tracking-widest border shadow-sm ' + asset()!.status.color">
                <i class="fas fa-circle text-[6px] mr-1.5 opacity-70"></i>
                {{ asset()!.status.name }}
              </span>
            </div>
            <p class="text-red-100 font-medium mt-1">{{ asset()!.brand }} {{ asset()!.model }} | SN: {{ asset()!.serial }}</p>
          </div>
          <div class="flex flex-wrap gap-2">
            <button (click)="close()" class="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm font-bold transition border border-white/20" title="Volver">
              <i class="fas fa-times"></i>
            </button>
            <button (click)="exportPdf()" class="px-4 py-2 rounded-lg bg-white text-[#DA291C] hover:bg-gray-100 text-sm font-bold transition shadow-md flex items-center">
              <i class="fas fa-file-pdf mr-2"></i> PDF
            </button>
            <button (click)="generateLoto()" class="px-4 py-2 rounded-lg bg-yellow-400 text-black hover:bg-yellow-300 text-sm font-bold transition shadow-md flex items-center">
              <i class="fas fa-lock mr-2"></i> Generar LOTO
            </button>
          </div>
        </div>

        <div class="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <!-- Column 1 & 2: Main Content -->
          <div class="lg:col-span-2 space-y-8">
            
            <!-- Quick Stats -->
            <div class="grid grid-cols-3 gap-4">
               <div class="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700 text-center">
                 <div class="text-xs text-slate-500 uppercase font-bold tracking-wider">Combustible</div>
                 <div class="font-bold text-slate-800 dark:text-white text-lg">{{ asset()!.fuelType }}</div>
               </div>
               <div class="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700 text-center">
                 <div class="text-xs text-slate-500 uppercase font-bold tracking-wider">Adquisición</div>
                 <div class="font-bold text-slate-800 dark:text-white text-lg">{{ asset()!.acquisitionDate | date:'MM/yyyy' }}</div>
               </div>
               <div class="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700 text-center">
                 <div class="text-xs text-slate-500 uppercase font-bold tracking-wider">Total Eventos</div>
                 <div class="font-bold text-slate-800 dark:text-white text-lg">{{ timelineHistory().length }}</div>
               </div>
            </div>

            <!-- Operations Actions Area -->
            <div class="bg-white dark:bg-slate-800/50 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
               <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                 <i class="fas fa-cogs"></i> Panel de Control Operativo
               </h3>

               @if (asset()!.status.name === 'Operativo') {
                  <div class="bg-red-50 dark:bg-red-500/10 p-5 rounded-lg border border-red-100 dark:border-red-500/20 relative">
                    <h4 class="text-[#DA291C] font-bold mb-3 flex items-center gap-2">
                       <i class="fas fa-tools"></i> Registrar Ingreso a Taller
                    </h4>
                    
                    <div class="flex flex-col gap-3">
                      <select #failType class="w-full p-2.5 border border-slate-300 dark:border-slate-600 rounded text-sm bg-white dark:bg-slate-700 focus:ring-2 focus:ring-red-500 outline-none">
                        <option>Falla Mecánica</option>
                        <option>Falla Eléctrica</option>
                        <option>Sistema Hidráulico</option>
                        <option>Llantas / Rodaje</option>
                        <option>Estructural</option>
                        <option>Daño por Operación</option>
                      </select>
                      
                      <textarea #failDesc class="w-full p-2.5 border border-slate-300 dark:border-slate-600 rounded text-sm bg-white dark:bg-slate-700 focus:ring-2 focus:ring-red-500 outline-none" rows="3" placeholder="Describe la falla detalladamente..."></textarea>

                      <button (click)="reportFailure(failDesc.value, failType.value)" class="w-full bg-[#DA291C] hover:bg-red-700 text-white font-bold py-2.5 rounded transition uppercase tracking-wide text-xs">Confirmar Ingreso</button>
                    </div>
                  </div>
               } @else if (asset()!.status.name === 'Taller') {
                  <div class="bg-emerald-50 dark:bg-emerald-500/10 p-5 rounded-lg border border-emerald-100 dark:border-emerald-500/20">
                    <h4 class="text-emerald-800 dark:text-emerald-300 font-bold mb-3 flex items-center gap-2">
                       <i class="fas fa-check-circle"></i> Finalizar y Liberar Equipo
                    </h4>
                    <div class="flex flex-col gap-3">
                      <textarea #diagnosis class="w-full p-2.5 border border-emerald-200 dark:border-emerald-800 rounded text-sm bg-white dark:bg-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none" rows="2" placeholder="Diagnóstico final y solución..."></textarea>
                      <div class="grid grid-cols-2 gap-3">
                        <input #cost type="number" class="p-2.5 border border-emerald-200 dark:border-emerald-800 rounded text-sm bg-white dark:bg-slate-700" placeholder="Costo Refacciones ($)">
                        <input #parts type="text" class="p-2.5 border border-emerald-200 dark:border-emerald-800 rounded text-sm bg-white dark:bg-slate-700" placeholder="Refacciones (separar por coma)">
                      </div>
                      <button (click)="finishRepair(diagnosis.value, cost.value, parts.value)" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded transition uppercase tracking-wide text-xs">Liberar Equipo a Operación</button>
                    </div>
                  </div>
               }
            </div>

            <!-- History Table -->
            <div>
              <div class="flex items-center gap-3 mb-4">
                 <div class="h-6 w-1 bg-[#DA291C]"></div>
                 <h3 class="text-lg font-bold text-slate-800 dark:text-white">Historial de Eventos</h3>
              </div>
              <div class="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
                <table class="w-full text-sm text-left min-w-[800px]">
                  <thead class="bg-slate-50 dark:bg-slate-900/50 text-slate-500 dark:text-slate-400 font-bold text-xs uppercase tracking-wider">
                    <tr>
                      <th class="p-3 whitespace-nowrap">Fecha</th>
                      <th class="p-3">Evento</th>
                      <th class="p-3">Detalle / Estatus</th>
                      <th class="p-3">Refacciones</th>
                      <th class="p-3">Tipo</th>
                      <th class="p-3 text-right">Costo</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                    @for (item of timelineHistory(); track item.id) {
                      <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/20 transition"
                          [class.bg-red-50/50]="item.isOpen && !item.isMaintenance" 
                          [class.dark:bg-red-500/5]="item.isOpen && !item.isMaintenance"
                          [class.bg-amber-50/50]="item.isOpen && item.isMaintenance"
                          [class.dark:bg-amber-500/5]="item.isOpen && item.isMaintenance">
                        <td class="p-3 text-slate-600 dark:text-slate-300 align-top whitespace-nowrap font-medium">
                          {{ item.date | date:'shortDate' }}
                           @if (item.isOpen) {
                             <span class="block text-center mt-1 px-2 py-0.5 rounded text-[10px] font-bold"
                                  [class.bg-red-500]="!item.isMaintenance" [class.text-white]="!item.isMaintenance"
                                  [class.bg-amber-500]="item.isMaintenance" [class.text-white]="item.isMaintenance">
                              ACTIVO
                            </span>
                          }
                        </td>
                        <td class="p-3 text-slate-800 dark:text-slate-100 align-top font-bold">{{ item.description }}</td>
                        <td class="p-3 text-slate-600 dark:text-slate-400 text-xs align-top max-w-[200px]">{{ item.details }}</td>
                        <td class="p-3 text-slate-600 dark:text-slate-400 text-xs align-top max-w-[200px]">
                           @if (item.parts && item.parts.length > 0) {
                             <div class="flex flex-wrap gap-1.5">
                               @for (part of item.parts; track $index) {
                                 <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-600">
                                   {{ part }}
                                 </span>
                               }
                             </div>
                           } @else { <span class="text-slate-400 italic text-xs">N/A</span> }
                        </td>
                        <td class="p-3 align-top">
                          <span class="px-2 py-1 text-xs font-bold uppercase rounded whitespace-nowrap"
                                [class.bg-slate-100]="!item.isMaintenance" [class.dark:bg-slate-700]="!item.isMaintenance" [class.text-slate-600]="!item.isMaintenance" [class.dark:text-slate-300]="!item.isMaintenance"
                                [class.bg-amber-100]="item.isMaintenance" [class.dark:bg-amber-800/50]="item.isMaintenance" [class.text-amber-700]="item.isMaintenance" [class.dark:text-amber-300]="item.isMaintenance">
                            {{ item.type }}
                          </span>
                        </td>
                        <td class="p-3 text-right font-mono text-slate-800 dark:text-slate-100 font-bold align-top whitespace-nowrap">{{ item.cost > 0 ? (item.cost | currency) : '-' }}</td>
                      </tr>
                    } @empty {
                      <tr><td colspan="6" class="p-8 text-center text-slate-400 italic">No hay historial de eventos para este activo.</td></tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- Column 3: AI Sidebar -->
          <div class="space-y-6">
            <div class="bg-slate-900 p-6 rounded-xl border border-slate-700 text-white shadow-xl">
              <div class="flex items-center gap-3 mb-4">
                <div class="p-2 bg-[#DA291C] text-white rounded shadow-sm"><i class="fas fa-robot text-lg"></i></div>
                <h3 class="text-lg font-bold">Mantenimiento Predictivo</h3>
              </div>
              <p class="text-sm text-slate-400 mb-6 leading-relaxed">Gemini AI analiza patrones de desgaste y MTBF para predecir fallas futuras.</p>

              @if (aiLoading()) {
                <div class="flex flex-col items-center justify-center py-6 text-center space-y-3">
                  <div class="relative">
                    <i class="fas fa-circle-notch fa-spin text-3xl text-[#DA291C]"></i>
                    <i class="fas fa-brain absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-xs text-white"></i>
                  </div>
                  <p class="text-xs font-bold text-slate-300 animate-pulse uppercase tracking-wide">Analizando historial y sensores...</p>
                </div>
              } @else if (aiResult()) {
                <div class="prose prose-sm prose-invert bg-white/5 p-4 rounded-lg border border-white/10 max-h-96 overflow-y-auto custom-scroll text-sm" [innerHTML]="aiResult()"></div>
                <button (click)="runAnalysis()" class="mt-4 w-full py-2 text-xs font-bold text-slate-400 hover:text-white uppercase tracking-wide border border-slate-700 rounded hover:bg-slate-800 transition">Regenerar Análisis</button>
              } @else {
                <div class="bg-white/5 rounded-lg p-3 mb-4 border border-white/10">
                   <p class="text-xs text-slate-400 italic mb-1"><i class="fas fa-info-circle mr-1"></i> Esto enviará el historial del equipo a Gemini.</p>
                </div>
                <button (click)="runAnalysis()" class="w-full py-3 bg-[#DA291C] hover:bg-red-700 text-white rounded-lg font-bold shadow-lg shadow-red-900/20 transition flex items-center justify-center gap-2 uppercase tracking-wide text-xs">
                  <i class="fas fa-magic"></i> Ejecutar Predicción con IA
                </button>
              }
            </div>

            @if (lotoResult()) {
               <div class="bg-yellow-50 dark:bg-yellow-500/10 p-6 rounded-xl border border-yellow-200 dark:border-yellow-500/20 shadow-lg">
                  <div class="flex justify-between items-center mb-4">
                     <h3 class="font-black text-yellow-800 dark:text-yellow-300 flex items-center gap-2"><i class="fas fa-lock"></i> Procedimiento LOTO</h3>
                     <button (click)="lotoResult.set(null)" class="text-yellow-600 hover:text-black dark:text-yellow-400 dark:hover:text-white"><i class="fas fa-times"></i></button>
                  </div>
                  <div class="prose prose-sm prose-yellow dark:prose-invert max-h-64 overflow-y-auto custom-scroll" [innerHTML]="lotoResult()"></div>
                  <button (click)="printLoto()" class="w-full mt-4 py-2 bg-yellow-400 hover:bg-yellow-500 text-black font-bold rounded uppercase text-xs">
                     <i class="fas fa-print mr-1"></i> Imprimir Etiqueta
                  </button>
               </div>
            }

            <!-- Visual AI Inspection Section -->
            <div class="bg-slate-50 dark:bg-slate-900/40 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-inner">
               <div class="flex items-center gap-3 mb-4">
                  <div class="p-2 bg-indigo-600 text-white rounded shadow-sm"><i class="fas fa-camera text-lg"></i></div>
                  <h3 class="text-lg font-bold text-slate-800 dark:text-white">Inspección Visual con IA</h3>
               </div>
               <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">Sube una fotografía de un componente dañado para obtener un diagnóstico técnico profundo, análisis de causa raíz y plan de reparación sugerido por Gemini.</p>

               <div class="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 bg-white dark:bg-slate-800/50 hover:bg-indigo-50 dark:hover:bg-indigo-900/10 transition-colors cursor-pointer relative group">
                  <input type="file" (change)="onFileSelected($event)" accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer z-10">
                  <div class="text-center space-y-2">
                     <i class="fas fa-cloud-upload-alt text-4xl text-slate-300 group-hover:text-indigo-500 transition-colors"></i>
                     <p class="text-sm font-bold text-slate-600 dark:text-slate-300">Haz clic o arrastra una imagen</p>
                     <p class="text-[10px] text-slate-400 uppercase tracking-widest">JPG, PNG hasta 5MB</p>
                  </div>
               </div>

               @if (visualAiLoading()) {
                  <div class="mt-6 flex flex-col items-center justify-center py-10 space-y-4">
                     <div class="relative">
                        <i class="fas fa-circle-notch fa-spin text-4xl text-indigo-600"></i>
                        <i class="fas fa-microscope absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-xs text-indigo-600"></i>
                     </div>
                     <p class="text-xs font-black text-indigo-600 animate-pulse uppercase tracking-widest">Procesando imagen con Visión Artificial...</p>
                  </div>
               }

               @if (visualAiResult()) {
                  <div class="mt-8 space-y-6 animate-fade-in">
                     <!-- Severity Header -->
                     <div class="flex items-center justify-between p-4 rounded-lg border-l-4 shadow-sm"
                          [class.bg-red-50]="visualAiResult()?.inspection?.severity?.level === 'CRÍTICA' || visualAiResult()?.inspection?.severity?.level === 'ALTA'"
                          [class.border-red-500]="visualAiResult()?.inspection?.severity?.level === 'CRÍTICA' || visualAiResult()?.inspection?.severity?.level === 'ALTA'"
                          [class.bg-amber-50]="visualAiResult()?.inspection?.severity?.level === 'MEDIA'"
                          [class.border-amber-500]="visualAiResult()?.inspection?.severity?.level === 'MEDIA'"
                          [class.bg-blue-50]="visualAiResult()?.inspection?.severity?.level === 'BAJA'"
                          [class.border-blue-500]="visualAiResult()?.inspection?.severity?.level === 'BAJA'">
                        <div>
                           <p class="text-[10px] font-black uppercase tracking-widest opacity-60">Severidad Detectada</p>
                           <h4 class="text-xl font-black" 
                               [class.text-red-700]="visualAiResult()?.inspection?.severity?.level === 'CRÍTICA' || visualAiResult()?.inspection?.severity?.level === 'ALTA'"
                               [class.text-amber-700]="visualAiResult()?.inspection?.severity?.level === 'MEDIA'"
                               [class.text-blue-700]="visualAiResult()?.inspection?.severity?.level === 'BAJA'">
                              {{ visualAiResult()?.inspection?.severity?.level }}
                           </h4>
                        </div>
                        <div class="text-right">
                           <p class="text-[10px] font-black uppercase tracking-widest opacity-60">Risk Score</p>
                           <span class="text-2xl font-black">{{ visualAiResult()?.inspection?.severity?.risk_score }}</span>
                        </div>
                     </div>

                     <!-- Analysis Grid -->
                     <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="bg-white dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700">
                           <h5 class="text-xs font-black text-slate-400 uppercase mb-3 flex items-center gap-2">
                              <i class="fas fa-search"></i> Identificación
                           </h5>
                           <p class="text-sm font-bold text-slate-800 dark:text-white">{{ visualAiResult()?.inspection?.asset?.component_affected }}</p>
                           <p class="text-xs text-slate-500 mt-1">{{ visualAiResult()?.inspection?.asset?.subcomponent }}</p>
                           <div class="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                              <p class="text-[10px] text-slate-400 font-bold uppercase">Condición Visual</p>
                              <p class="text-xs text-slate-600 dark:text-slate-400 mt-1 italic">"{{ visualAiResult()?.inspection?.asset?.visual_condition }}"</p>
                           </div>
                        </div>

                        <div class="bg-white dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700">
                           <h5 class="text-xs font-black text-slate-400 uppercase mb-3 flex items-center gap-2">
                              <i class="fas fa-biohazard"></i> Análisis de Daño
                           </h5>
                           <span class="inline-block px-2 py-0.5 rounded bg-red-100 text-red-700 text-[10px] font-bold uppercase mb-2">{{ visualAiResult()?.inspection?.damage_analysis?.damage_type }}</span>
                           <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{{ visualAiResult()?.inspection?.damage_analysis?.technical_description }}</p>
                           <div class="mt-2 flex flex-wrap gap-1">
                              @for (sign of visualAiResult()?.inspection?.damage_analysis?.visible_signs; track sign) {
                                 <span class="text-[9px] bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-500">{{ sign }}</span>
                              }
                           </div>
                        </div>
                     </div>

                     <!-- Root Cause & Actions -->
                     <div class="bg-slate-800 text-white p-5 rounded-xl border border-slate-700 shadow-lg">
                        <h5 class="text-xs font-black text-indigo-400 uppercase mb-4 flex items-center gap-2">
                           <i class="fas fa-project-diagram"></i> Análisis Causa Raíz (5 Whys)
                        </h5>
                        <div class="space-y-3">
                           @for (why of visualAiResult()?.inspection?.root_cause_analysis?.why_analysis; track $index) {
                              <div class="flex gap-3 items-start">
                                 <div class="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">{{ $index + 1 }}</div>
                                 <p class="text-xs text-slate-300 leading-tight">{{ why }}</p>
                              </div>
                           }
                        </div>
                        <div class="mt-5 pt-5 border-t border-slate-700 grid grid-cols-2 gap-4">
                           <div>
                              <p class="text-[10px] font-black text-emerald-400 uppercase mb-2">Medidas de Seguridad</p>
                              <ul class="text-[10px] space-y-1 text-slate-400">
                                 @for (action of visualAiResult()?.inspection?.immediate_actions?.safety_measures; track action) {
                                    <li class="flex items-center gap-1.5"><i class="fas fa-check text-emerald-500"></i> {{ action }}</li>
                                 }
                              </ul>
                           </div>
                           <div>
                              <p class="text-[10px] font-black text-blue-400 uppercase mb-2">Plan de Reparación</p>
                              <p class="text-[10px] text-slate-300 font-bold">MTTR Est: {{ visualAiResult()?.inspection?.repair_plan?.estimated_mttr_hours }}</p>
                              <p class="text-[10px] text-slate-400 mt-1">Costo Est: {{ visualAiResult()?.inspection?.repair_plan?.estimated_cost_usd?.min }} - {{ visualAiResult()?.inspection?.repair_plan?.estimated_cost_usd?.max }} USD</p>
                           </div>
                        </div>
                     </div>

                     <button (click)="visualAiResult.set(null)" class="w-full py-2 text-xs font-bold text-slate-400 hover:text-slate-600 uppercase tracking-widest transition">Limpiar Inspección</button>
                  </div>
               }
            </div>
          </div>
        </div>
      </div>
    }
  `
})
export class AssetDetailComponent {
  assetId = input<string>('');
  
  private dataService = inject(DataService);
  private geminiService = inject(GeminiService);

  asset = computed(() => this.dataService.getAsset(this.assetId()));
  private failureHistory = computed(() => this.assetId() ? this.dataService.getAssetHistory(this.assetId()) : []);
  
  timelineHistory = computed<HistoryTimelineItem[]>(() => {
    const asset = this.asset();
    if (!asset) return [];

    const failures: HistoryTimelineItem[] = this.failureHistory().map(f => ({
      id: f.id,
      isMaintenance: false,
      date: f.entryDate,
      description: f.failureDescription,
      details: f.diagnosis || '-',
      parts: f.partsUsed,
      type: f.type,
      cost: f.estimatedCost,
      isOpen: !f.exitDate
    }));

    const maintenance: HistoryTimelineItem[] = (asset.maintenanceTasks || []).map(m => ({
      id: m.id,
      isMaintenance: true,
      date: m.date,
      description: m.description,
      details: m.status,
      parts: [],
      type: 'Preventivo',
      cost: 0,
      isOpen: m.status !== 'Completed'
    }));

    // Combine and sort
    return [...failures, ...maintenance].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });
  
  aiLoading = signal(false);
  aiResult = signal<string | null>(null);

  // Visual AI Inspection
  visualAiLoading = signal(false);
  visualAiResult = signal<AIInspectionResponse | null>(null);

  // New Signals for Prompts
  lotoResult = signal<string | null>(null);

  constructor() {
    effect(() => {
      // Reset state when asset changes
      this.assetId();
      this.aiResult.set(null);
      this.lotoResult.set(null);
    }, { allowSignalWrites: true });
  }

  // --- Visual AI Inspection ---
  async onFileSelected(event: any) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e: any) => {
      const base64 = e.target.result.split(',')[1];
      const mimeType = file.type;
      await this.runVisualInspection(base64, mimeType);
    };
    reader.readAsDataURL(file);
  }

  async runVisualInspection(base64: string, mimeType: string) {
    this.visualAiLoading.set(true);
    this.visualAiResult.set(null);
    try {
      const result = await this.geminiService.analyzeImage(base64, mimeType);
      this.visualAiResult.set(result);
    } catch (error) {
      console.warn('ALERT:', 'Error en el análisis visual de IA. Intente con otra imagen.');
    } finally {
      this.visualAiLoading.set(false);
    }
  }

  // --- Actions ---
  
  // Bonus 3: Generate LOTO
  async generateLoto() {
    const currentAsset = this.asset();
    if (!currentAsset) return;
    
    // Uses the last failure or a generic context
    const lastFailure = currentAsset.lastFailure || "Mantenimiento General Preventivo";
    
    this.lotoResult.set('<p class="text-gray-500 animate-pulse">Generando procedimiento de seguridad...</p>');
    const html = await this.geminiService.generateLotoProcedure(currentAsset, lastFailure);
    this.lotoResult.set(html);
  }

  printLoto() {
    const printWindow = window.open('', '', 'height=600,width=800');
    if(printWindow && this.lotoResult()) {
      printWindow.document.write('<html><head><title>LOTO</title>');
      printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
      printWindow.document.write('</head><body class="p-8">');
      printWindow.document.write(this.lotoResult()!);
      printWindow.document.write('</body></html>');
      printWindow.document.close();
      setTimeout(() => printWindow.print(), 500);
    }
  }

  reportFailure(desc: string, type: any) {
    if (!desc) return console.warn('ALERT:', 'Por favor describe la falla.');
    this.dataService.reportFailure(this.assetId(), desc, type);
  }

  finishRepair(diag: string, costStr: string, partsStr: string) {
    if (!diag) return console.warn('ALERT:', 'El diagnóstico es requerido.');
    const cost = parseFloat(costStr) || 0;
    const parts = partsStr.split(',').map(p => p.trim()).filter(p => p);
    
    this.dataService.completeRepair(this.assetId(), diag, cost, parts);
  }

  async runAnalysis() {
    const currentAsset = this.asset();
    if (!currentAsset) return;

    this.aiLoading.set(true);
    // Use the failure history for analysis, which is now populated correctly
    const historyForAI = this.failureHistory(); 
    const result = await this.geminiService.analyzeMaintenanceHistory(currentAsset, historyForAI);
    this.aiResult.set(result);
    this.aiLoading.set(false);
  }

  exportPdf() {
    try {
        const doc = new jsPDF();
        const currentAsset = this.asset();
        if (!currentAsset) return;

        // Header
        doc.setFontSize(20);
        doc.setTextColor(218, 41, 28); // Coca Cola Red
        doc.text(`Historial de Eventos: ${currentAsset.id}`, 14, 20);
        
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(10);
        doc.text(`Marca: ${currentAsset.brand} | Modelo: ${currentAsset.model}`, 14, 28);
        doc.text(`Serie: ${currentAsset.serial} | Estatus: ${currentAsset.status.name}`, 14, 33);
        doc.text(`Generado: ${new Date().toLocaleDateString()}`, 14, 38);

        // Table
        const tableData = this.timelineHistory().map(row => [
        new Date(row.date).toLocaleDateString(),
        row.description,
        row.details,
        row.parts.join(', '),
        row.type,
        `$${row.cost}`
        ]);

        autoTable(doc, {
        startY: 45,
        head: [['Fecha', 'Evento', 'Detalle/Estatus', 'Refacciones', 'Tipo', 'Costo']],
        body: tableData,
        theme: 'grid',
        headStyles: { fillColor: [218, 41, 28] } // Coca Cola Red Header
        });

        doc.save(`historial_${currentAsset.id}.pdf`);
    } catch(e) {
        console.error("PDF Error", e);
        console.warn('ALERT:', "Error al exportar el historial. Intente nuevamente.");
    }
  }

  sendEmail() {
    const currentAsset = this.asset();
    if (!currentAsset) return;

    const subject = encodeURIComponent(`Seguimiento de Activo ${currentAsset.id} - ${currentAsset.status.name}`);
    const bodyText = `
Hola,

Adjunto el seguimiento para el equipo:
ID: ${currentAsset.id}
Marca: ${currentAsset.brand}
Modelo: ${currentAsset.model}
Serie: ${currentAsset.serial}

Estatus Actual: ${currentAsset.status.name}
Última Falla Registrada: ${currentAsset.lastFailure || 'N/A'}

Favor de revisar el historial en el sistema para más detalles.

Saludos,
AssetGuard System
    `.trim();

    const body = encodeURIComponent(bodyText);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  }

  close() {
    window.dispatchEvent(new CustomEvent('asset-closed'));
  }

  printReport() {
    window.print();
  }
}
