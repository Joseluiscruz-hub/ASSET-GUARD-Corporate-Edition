
export interface Status {
  id: string;
  name: 'Operativo' | 'Taller' | 'Baja' | 'Preventivo';
  color: string; // Tailwind class or Hex
  hex: string;
}

export interface Asset {
  id: string; // Economic ID
  brand: string;
  model: string;
  serial: string;
  acquisitionDate: string;
  fuelType: 'Eléctrico' | 'Gas LP' | 'Diesel';
  status: Status;
  statusSince: string; // ISO Date
  image?: string;
  
  // New fields from architecture
  location: string; // Ubicacion (e.g. Pasillo 4)
  lastFailure?: string; // Description of last failure
  critical: boolean; // Priority flag
}

export interface FailureReport {
  id: string;
  assetId: string;
  entryDate: string; // ISO Date
  exitDate?: string | null; // ISO Date or null
  failureDescription: string;
  diagnosis?: string;
  partsUsed: string[];
  estimatedCost: number;
  technician: string;
  type: 'Eléctrico' | 'Mecánico' | 'Hidráulico' | 'Operador' | 'Llantas';
}

export interface KPIData {
  availability: number; // Percentage
  mttr: number; // Hours
  totalCostMonth: number;
  budgetMonth: number;
}
