import { Component, Input, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

export type KpiStatus = 'success' | 'warning' | 'danger' | 'info' | 'neutral';

@Component({
  selector: 'app-kpi-card',
  standalone: true,
  imports: [CommonModule],
  template: `
    <article class="h-full bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700/50 shadow-sm p-5 flex flex-col gap-2 transition-all hover:shadow-lg hover:-translate-y-1 relative overflow-hidden"
             [class]="borderClass()">
      
      <!-- Header -->
      <header class="flex items-start justify-between z-10">
        <div>
          <h2 class="text-sm font-bold text-slate-600 dark:text-slate-200">{{ title }}</h2>
          <p class="text-xs text-slate-400 mt-0.5">{{ subtitle }}</p>
        </div>
      </header>

      <!-- Main Value -->
      <div class="flex items-baseline gap-2 mt-2 z-10">
        <span class="text-4xl font-black tracking-tight text-slate-800 dark:text-slate-50">{{ value }}</span>
        <span class="text-sm font-bold text-slate-400">{{ unit }}</span>
      </div>
      
      <div class="text-xs font-semibold" [class]="statusTextColor()">
        {{ statusText }}
      </div>

      <!-- Footer -->
      <footer class="mt-auto flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-4 z-10">
        <span>{{ footerLabel }}: <span class="text-slate-700 dark:text-slate-200 font-bold">{{ footerValue }}</span></span>
        <span [class]="trendClass()">{{ trendLabel }}</span>
      </footer>
    </article>
  `
})
export class KpiCardComponent {
  @Input() title = '';
  @Input() subtitle = '';
  @Input() value: string | number = '';
  @Input() unit = '';
  @Input() status: KpiStatus = 'neutral';
  @Input() statusText = '';
  
  @Input() footerLabel = '';
  @Input() footerValue = '';
  @Input() trendLabel = '';
  
  borderClass = computed(() => {
    switch (this.status) {
      case 'success': return 'border-t-4 border-t-emerald-500';
      case 'warning': return 'border-t-4 border-t-amber-500';
      case 'danger': return 'border-t-4 border-t-red-500';
      case 'info': return 'border-t-4 border-t-sky-500';
      default: return 'border-t-4 border-t-slate-300';
    }
  });

  statusTextColor = computed(() => {
    switch (this.status) {
      case 'success': return 'text-emerald-600 dark:text-emerald-400';
      case 'warning': return 'text-amber-600 dark:text-amber-400';
      case 'danger': return 'text-red-600 dark:text-red-400';
      case 'info': return 'text-sky-600 dark:text-sky-400';
      default: return 'text-slate-500 dark:text-slate-400';
    }
  });

  trendClass = computed(() => {
     if (this.status === 'danger') return 'text-red-600 dark:text-red-400 font-bold';
    if (this.status === 'warning') return 'text-amber-600 dark:text-amber-400 font-bold';
    return 'text-emerald-600 dark:text-emerald-400 font-bold';
  });
}