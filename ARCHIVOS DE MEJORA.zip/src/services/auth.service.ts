import { Injectable, signal } from '@angular/core';
import { auth, db } from '../firebase';
import { 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User 
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  role: 'admin' | 'planner' | 'technician' | 'viewer';
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  readonly currentUser = signal<User | null>(null);
  readonly userProfile = signal<UserProfile | null>(null);
  readonly isAuthReady = signal(false);

  constructor() {
    onAuthStateChanged(auth, async (user) => {
      this.currentUser.set(user);
      if (user) {
        await this.syncUserProfile(user);
      } else {
        this.userProfile.set(null);
      }
      this.isAuthReady.set(true);
    });
  }

  async login() {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      await this.syncUserProfile(result.user);
    } catch (error) {
      console.error('Login error:', error);
    }
  }

  async logout() {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  }

  private async syncUserProfile(user: User) {
    const userDocRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userDocRef);

    if (userDoc.exists()) {
      this.userProfile.set(userDoc.data() as UserProfile);
    } else {
      const profile: UserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || '',
        photoURL: user.photoURL || '',
        role: user.email === 'mimonkb222@gmail.com' ? 'admin' : 'viewer'
      };
      await setDoc(userDocRef, profile);
      this.userProfile.set(profile);
    }
  }

  hasRole(roles: string[]): boolean {
    const profile = this.userProfile();
    return profile ? roles.includes(profile.role) : false;
  }
}
