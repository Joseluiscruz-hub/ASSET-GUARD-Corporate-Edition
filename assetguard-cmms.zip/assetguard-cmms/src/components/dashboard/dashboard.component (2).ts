import { Component, inject, computed, signal } from '@angular/core';
import { CommonModule, DatePipe, CurrencyPipe } from '@angular/common';
import { DataService } from '../../services/data.service';
import { KpiCardComponent, KpiStatus } from '../ui/kpi-card.component';
import { ForkliftFailureEntry } from '../../types';

@Component({
  selector: 'app-dashboard',
  standalone: true, 
  imports: [CommonModule, KpiCardComponent, DatePipe, CurrencyPipe],
  template: `
    <div class="space-y-6 pb-10">
      
      <!-- ROW 1: EXECUTIVE KPIS -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        
        <!-- Safety -->
        <app-kpi-card 
          title="Seguridad" 
          subtitle="Días sin incidentes"
          [value]="safetyStats().daysWithoutAccident" 
          unit="días" 
          status="success"
          statusText="Récord: {{safetyStats().record}} días"
          footerLabel="Anuncio"
          [footerValue]="safetyStats().announcement"
          [trendLabel]="'Faltan ' + (safetyStats().record - safetyStats().daysWithoutAccident) + ' para récord'">
        </app-kpi-card>

        <!-- Availability -->
        <app-kpi-card 
          title="Disponibilidad" 
          subtitle="Flota operativa efectiva"
          [value]="fleetAvailability().percentage" 
          unit="%" 
          [status]="availabilityStatus()"
          [statusText]="availabilityStatusText()"
          footerLabel="Meta"
          footerValue="95%"
          [trendLabel]="availabilityGap()">
        </app-kpi-card>

        <!-- Active Fleet -->
        <app-kpi-card 
          title="Flota Activa" 
          subtitle="Estado actual de montacargas"
          [value]="operativeCount()" 
          [unit]="'de ' + totalAssets()" 
          status="info"
          statusText="Vista general"
          footerLabel="En Taller"
          [footerValue]="activeFailures().length + (activeFailures().length === 1 ? ' unidad' : ' unidades')"
          [trendLabel]="fleetCapacityLabel()">
        </app-kpi-card>

        <!-- Cost -->
        <app-kpi-card 
          title="Costo Mensual" 
          subtitle="Mantenimiento y refacciones"
          [value]="kpi().totalCostMonth"
          [unit]="'USD'" 
          [status]="budgetStatus()"
          [statusText]="budgetStatusText()"
          footerLabel="Presupuesto"
          [footerValue]="(kpi().budgetMonth | currency) || '$0'"
          [trendLabel]="budgetVariance()">
        </app-kpi-card>
      </div>

      <!-- ROW 2: LIVE WORKSHOP & PARETO -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- COL 1 (2/3): TALLER EN VIVO -->
        <div class="lg:col-span-2 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700/80 flex flex-col h-[550px]">
          <div class="p-5 border-b border-slate-200 dark:border-slate-700/80 flex justify-between items-center">
            <div>
               <h3 class="font-bold text-slate-800 dark:text-white flex items-center gap-3">
                 <i class="fas fa-wrench text-slate-400"></i> Taller en Vivo
               </h3>
               <p class="text-xs text-slate-500 mt-1">Órdenes de trabajo activas y tiempos de respuesta.</p>
            </div>
            
            @if (activeFailures().length > 0) {
               <div class="flex items-center gap-2 text-xs font-bold text-red-600 bg-red-50 dark:bg-red-500/10 px-3 py-1 rounded-full border border-red-100 dark:border-red-500/20">
                 <span class="relative flex h-2 w-2">
                   <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                   <span class="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                 </span>
                 {{ activeFailures().length }} {{ activeFailures().length === 1 ? 'unidad' : 'unidades' }} en atención
               </div>
            }
          </div>
          
          <div class="flex-1 overflow-y-auto custom-scroll">
             <table class="w-full text-left text-sm">
                <thead class="bg-slate-50 dark:bg-slate-900/50 text-slate-500 dark:text-slate-400 font-bold text-xs uppercase sticky top-0 z-10 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th class="p-4 pl-6">Unidad / Prioridad</th>
                    <th class="p-4 w-1/3">Falla Reportada</th>
                    <th class="p-4">Estado Actual</th>
                    <th class="p-4 text-center">Tiempo en Taller</th>
                    <th class="p-4 text-right pr-6"></th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                  @for (f of activeFailures(); track f.id) {
                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/20 transition-colors group">
                      <!-- ID & Priority -->
                      <td class="p-4 pl-6 align-top">
                         <div class="font-black text-slate-800 dark:text-white text-base">{{ f.economico }}</div>
                         <div class="flex items-center gap-1.5 mt-1">
                            <div [class]="'w-2 h-2 rounded-full ' + getPriorityColor(f.prioridad)"></div>
                            <span class="text-[10px] font-bold uppercase text-slate-500">{{ f.prioridad }}</span>
                         </div>
                      </td>
                      
                      <!-- Failure Description -->
                      <td class="p-4 align-top">
                          <div class="font-bold text-slate-700 dark:text-slate-200 max-w-[250px]">{{ f.falla }}</div>
                          <div class="text-[11px] text-slate-400 font-mono mt-1">{{ f.fechaIngreso | date:'dd MMM yyyy, HH:mm' }}h</div>
                      </td>

                      <!-- Status Badge -->
                      <td class="p-4 align-top">
                        <span [class]="'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase border ' + getStatusBadgeClass(f)">
                           <span [class]="'w-2 h-2 rounded-full ' + getStatusDotClass(f)"></span>
                           {{ f.estatus === 'Abierta' ? 'Diagnóstico' : (f.estatusRefaccion ? 'Refacciones' : 'En Reparación') }}
                        </span>
                      </td>

                      <!-- Time In Shop -->
                      <td class="p-4 text-center align-top">
                         <div class="flex flex-col items-center justify-center">
                            <span class="font-mono text-base font-black" [class]="getTimeInShop(f.fechaIngreso).colorClass">
                               {{ getTimeInShop(f.fechaIngreso).text }}
                            </span>
                            <span class="text-[10px] font-bold uppercase text-slate-400">
                               {{ getTimeInShop(f.fechaIngreso).label }}
                            </span>
                         </div>
                      </td>

                      <!-- Action Button -->
                      <td class="p-4 pr-6 text-right align-top">
                        <button (click)="selectAsset(f.economico)" 
                                class="bg-white dark:bg-slate-700/70 border border-slate-200 dark:border-slate-600 text-slate-500 dark:text-slate-300 hover:text-[#DA291C] hover:border-red-300 dark:hover:text-red-400 px-3 py-1.5 rounded-md text-xs font-bold transition-all shadow-sm hover:shadow-md hover:scale-105 active:scale-95">
                          Detalles <i class="fas fa-arrow-right text-[9px] ml-1"></i>
                        </button>
                      </td>
                    </tr>
                  } @empty {
                    <tr>
                      <td colspan="5" class="py-20 text-center">
                        <div class="flex flex-col items-center justify-center opacity-60">
                           <div class="w-16 h-16 bg-emerald-50 dark:bg-emerald-500/10 rounded-full flex items-center justify-center mb-4 border border-emerald-100 dark:border-emerald-800">
                              <i class="fas fa-check-circle text-3xl text-emerald-500"></i>
                           </div>
                           <h3 class="text-slate-800 dark:text-white font-bold text-lg">Sin Unidades en Taller</h3>
                           <p class="text-slate-500 text-sm mt-1 mb-4">La flota opera al 100% de su capacidad.</p>
                        </div>
                      </td>
                    </tr>
                  }
                </tbody>
             </table>
          </div>
        </div>

        <!-- COL 2 (1/3): PARETO CARDS + TIMELINE -->
        <div class="flex flex-col gap-6">
           
           <!-- Pareto Cards -->
           <div class="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-5">
              <div class="flex justify-between items-center mb-4">
                 <h3 class="font-bold text-slate-800 dark:text-white text-sm">Pareto de Fallas (30d)</h3>
                 <i class="fas fa-filter text-slate-400"></i>
              </div>
              
              <div class="space-y-3">
                 @for(item of paretoData(); track item.type) {
                  <button (click)="filterByIssue(item.type)" class="w-full text-left p-3 rounded-lg bg-slate-50/80 dark:bg-slate-900/30 border border-slate-200/80 dark:border-slate-700 group hover:border-red-300 dark:hover:border-red-600 transition-colors cursor-pointer relative">
                      <div class="flex justify-between items-center mb-2">
                         <span class="text-xs font-bold text-slate-700 dark:text-slate-200 group-hover:text-[#DA291C] transition-colors">{{ item.type }}</span>
                         <span class="text-xs font-black" [style.color]="item.color">{{ item.percentage }}%</span>
                      </div>
                      <div class="w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden">
                         <div class="h-full" [style.background]="item.color" [style.width.%]="item.percentage"></div>
                      </div>
                   </button>
                 }
              </div>
           </div>

           <!-- Mini Timeline (Events) -->
           <div class="flex-1 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-5 flex flex-col">
              <div class="flex justify-between items-center mb-4">
                 <h3 class="font-bold text-slate-800 dark:text-white text-sm">Bitácora de Eventos</h3>
                 <button class="text-[10px] font-bold text-[#DA291C] hover:underline">Ver todo</button>
              </div>
              
              <div class="space-y-5">
                @for (group of groupedEvents(); track group.groupName) {
                  <div>
                    <h4 class="text-[10px] font-bold uppercase text-slate-400 dark:text-slate-500 pb-2 mb-4 border-b border-slate-200 dark:border-slate-700">{{ group.groupName }}</h4>
                    <div class="relative pl-6 border-l-2 border-slate-200 dark:border-slate-700 space-y-5">
                      @for (event of group.events; track $index) {
                        <div class="relative group">
                           <div class="absolute -left-[10px] top-1 h-4 w-4 rounded-full border-4 border-white dark:border-slate-800 flex items-center justify-center shadow-sm" [ngClass]="event.color"></div>
                           
                           <p class="text-xs font-bold text-slate-700 dark:text-slate-200 leading-tight">{{ event.title }}</p>
                           <div class="flex items-center gap-2 mt-1">
                              <span class="text-[10px] text-slate-400 font-mono">{{ event.time }}</span>
                              <span class="text-[10px] bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-500 dark:text-slate-300 font-semibold">{{ event.user }}</span>
                           </div>
                        </div>
                      }
                    </div>
                  </div>
                } @empty {
                  <div class="text-center py-10">
                    <p class="text-xs text-slate-400">No hay eventos recientes.</p>
                  </div>
                }
              </div>
           </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .fade-enter { animation: fadeIn 0.3s ease-out forwards; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
  `]
})
export class DashboardComponent {
  dataService = inject(DataService);

  kpi = this.dataService.kpiData;
  safetyStats = this.dataService.safetyStats;
  fleetAvailability = this.dataService.fleetAvailability;
  activeFailures = computed(() => this.dataService.forkliftFailures().filter(f => f.estatus !== 'Cerrada'));
  operativeCount = computed(() => this.dataService.assets().filter(a => a.status.name === 'Operativo').length);
  totalAssets = computed(() => this.dataService.assets().length);
  lastUpdate = this.dataService.lastUpdate;

  // Visual logic helpers
  availabilityStatus = computed<KpiStatus>(() => {
    const p = this.fleetAvailability().percentage;
    if (p >= 95) return 'success';
    if (p >= 85) return 'warning';
    return 'danger';
  });

  availabilityStatusText = computed(() => {
    const p = this.fleetAvailability().percentage;
    if (p >= 95) return 'Meta Cumplida';
    if (p >= 85) return 'En Riesgo';
    return 'Nivel Crítico';
  });

  availabilityGap = computed(() => {
    const p = this.fleetAvailability().percentage;
    const diff = p - 95;
    const sign = diff >= 0 ? '+' : '';
    return `Brecha: ${sign}${diff.toFixed(0)} pts`;
  });

  fleetCapacityLabel = computed(() => {
    const total = this.totalAssets();
    if (total === 0) return '0% capacidad';
    const operative = this.operativeCount();
    const pct = Math.round((operative / total) * 100);
    return `${pct}% de capacidad operativa`;
  });

  budgetStatus = computed<KpiStatus>(() => {
    const cost = this.kpi().totalCostMonth;
    const budget = this.kpi().budgetMonth;
    if (cost > budget) return 'danger';
    if (cost > budget * 0.9) return 'warning';
    return 'success';
  });

  budgetStatusText = computed(() => {
    const cost = this.kpi().totalCostMonth;
    const budget = this.kpi().budgetMonth;
    if (cost > budget) return 'Presupuesto Excedido';
    return 'Bajo Control';
  });

  budgetVariance = computed(() => {
     const cost = this.kpi().totalCostMonth;
     const budget = this.kpi().budgetMonth;
     if (budget === 0) return 'N/A';
     const variance = ((cost - budget) / budget) * 100;
     return variance > 0 ? `+${variance.toFixed(0)}% vs Presupuesto` : `${variance.toFixed(0)}% vs Presupuesto`;
  });

  // Mock data for Pareto
  paretoData = signal([
    { type: 'Sistema Hidráulico', percentage: 45, color: '#ef4444' },
    { type: 'Frenos y Desgaste', percentage: 20, color: '#f59e0b' },
    { type: 'Componentes Eléctricos', percentage: 15, color: '#3b82f6' }
  ]);
  
  // Timeline Mock with Icons and Dates for Grouping
  recentEvents = computed(() => {
     const now = new Date();
     const yesterday = new Date();
     yesterday.setDate(now.getDate() - 1);

     return [
        { date: now.toISOString(), title: 'Unidad 35526 ingresó a Taller por fuga hidráulica.', time: 'Hace 15 min', user: 'Op. Móvil', color: 'bg-red-500', icon: 'fa-exclamation-circle' },
        { date: now.toISOString(), title: 'Refacción "Kit de Sellos" solicitada para OT-35526.', time: 'Hace 45 min', user: 'Toyota Tech', color: 'bg-blue-500', icon: 'fa-box-open' },
        { date: now.toISOString(), title: 'Turno Matutino inició operaciones, 98% disponibilidad.', time: '06:00 AM', user: 'Sistema', color: 'bg-emerald-500', icon: 'fa-check' },
        { date: yesterday.toISOString(), title: 'Unidad 40019 completó mantenimiento preventivo (SMP-X).', time: 'Ayer, 18:30', user: 'Sistema', color: 'bg-emerald-500', icon: 'fa-check-double' },
        { date: yesterday.toISOString(), title: 'Alerta de batería baja registrada en unidad 37192.', time: 'Ayer, 11:00', user: 'Sensor IoT', color: 'bg-amber-500', icon: 'fa-battery-quarter' }
     ];
  });

  groupedEvents = computed(() => {
    const events: any[] = this.recentEvents();
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    const isSameDay = (d1: Date, d2: Date) => 
      d1.getFullYear() === d2.getFullYear() &&
      d1.getMonth() === d2.getMonth() &&
      d1.getDate() === d2.getDate();

    const groups: { groupName: string; events: any[] }[] = [];
    
    const todayEvents = events.filter(e => isSameDay(new Date(e.date), today)).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    const yesterdayEvents = events.filter(e => isSameDay(new Date(e.date), yesterday)).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    if (todayEvents.length > 0) {
      groups.push({ groupName: 'Hoy', events: todayEvents });
    }
    if (yesterdayEvents.length > 0) {
      groups.push({ groupName: 'Ayer', events: yesterdayEvents });
    }
    
    return groups;
  });

  selectAsset(id: string) {
    window.dispatchEvent(new CustomEvent('asset-selected', { detail: id }));
  }

  filterByIssue(issue: string) {
    console.warn('ALERT:', `[DEMO] Filtrando activos con fallas en: ${issue}`);
  }

  downloadReport() {
    window.print();
  }

  getTimeInShop(dateStr: string) {
    const start = new Date(dateStr).getTime();
    const now = new Date().getTime();
    const diffHrs = Math.floor((now - start) / (1000 * 60 * 60));
    
    let text: string;
    let label: string;
    let colorClass: string;

    if (diffHrs < 24) { text = `${diffHrs}h`; } 
    else { const days = Math.floor(diffHrs / 24); text = `${days}d ${diffHrs % 24}h`; }

    if (diffHrs < 24) { label = 'Normal'; colorClass = 'text-slate-700 dark:text-slate-200'; } 
    else if (diffHrs < 48) { label = 'Retrasado'; colorClass = 'text-amber-600 dark:text-amber-400'; } 
    else { label = 'Crítico'; colorClass = 'text-red-600 dark:text-red-400 animate-pulse'; }

    return { text, label, colorClass };
  }

  getStatusBadgeClass(f: ForkliftFailureEntry): string {
    if (f.estatus === 'Abierta') return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/10 dark:text-amber-400 dark:border-amber-500/20';
    if (f.estatusRefaccion === 'Pedida' || f.estatusRefaccion === 'Por Recibir') return 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-500/10 dark:text-purple-400 dark:border-purple-500/20';
    return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-500/10 dark:text-blue-400 dark:border-blue-500/20';
  }

  getStatusDotClass(f: ForkliftFailureEntry): string {
    if (f.estatus === 'Abierta') return 'bg-amber-500';
    if (f.estatusRefaccion === 'Pedida' || f.estatusRefaccion === 'Por Recibir') return 'bg-purple-500';
    return 'bg-blue-500';
  }

  getPriorityColor(p: string): string {
     if (p === 'Alta') return 'bg-red-500';
     if (p === 'Media') return 'bg-amber-500';
     return 'bg-slate-400';
  }
}
