import { Injectable, signal, computed, effect, inject } from '@angular/core';
import { Asset, FailureReport, Status, KPIData, ForkliftFailureEntry, FailureUpdate, MaintenanceTask, MaintenanceSchedule, ScheduleHistory, InventoryPart, WorkOrder } from '../types';
import { hydrateRealAssets, REAL_FLEET_DATA } from '../data/real-fleet';
import { db, auth } from '../firebase';
import { AuthService } from './auth.service';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  updateDoc, 
  query, 
  orderBy, 
  getDoc,
  getDocs,
  getDocFromServer
} from 'firebase/firestore';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

@Injectable({
  providedIn: 'root'
})
export class DataService {
  
  // --- System State Signals ---
  readonly connectionStatus = signal<'online' | 'offline' | 'syncing'>('online');
  readonly lastUpdate = signal<Date>(new Date());
  readonly plantMode = signal<boolean>(false); // Dark/Light Theme
  readonly isKioskMode = signal<boolean>(false);
  readonly activeSlide = signal<number>(0); 
  private kioskInterval: any;

  // --- Master Catalogs ---
  readonly statuses: Status[] = [
    { id: '1', name: 'Operativo', color: 'bg-emerald-100 text-emerald-800 border-emerald-200', hex: '#10b981' },
    { id: '2', name: 'Taller', color: 'bg-red-100 text-red-800 border-red-200', hex: '#ef4444' },
    { id: '3', name: 'Preventivo', color: 'bg-amber-100 text-amber-800 border-amber-200', hex: '#f59e0b' },
    { id: '4', name: 'Baja', color: 'bg-slate-100 text-slate-800 border-slate-200', hex: '#64748b' },
  ];

  // --- Business Data Signals ---
  private assetsSignal = signal<Asset[]>([]);
  private reportsSignal = signal<FailureReport[]>([]);
  readonly forkliftFailures = signal<ForkliftFailureEntry[]>([]);
  readonly maintenanceSchedule = signal<MaintenanceSchedule[]>([]);
  readonly inventory = signal<InventoryPart[]>([
    { id: 'INV-001', sku: 'MTR-001', name: 'Motor Eléctrico 5HP', category: 'Eléctrico', stock: 4, minStock: 2, unitCost: 450, location: 'Almacén A - Estante 1', supplier: 'Siemens' },
    { id: 'INV-002', sku: 'BMB-002', name: 'Bomba Hidráulica 20GPM', category: 'Hidráulico', stock: 1, minStock: 3, unitCost: 850, location: 'Almacén B - Estante 3', supplier: 'Bosch Rexroth' },
    { id: 'INV-003', sku: 'FLT-003', name: 'Filtro de Aceite', category: 'Consumible', stock: 45, minStock: 20, unitCost: 15, location: 'Almacén A - Estante 5', supplier: 'Donaldson' },
    { id: 'INV-004', sku: 'BND-004', name: 'Banda de Transmisión V', category: 'Mecánico', stock: 12, minStock: 10, unitCost: 35, location: 'Almacén A - Estante 2', supplier: 'Gates' },
    { id: 'INV-005', sku: 'VLV-005', name: 'Válvula Neumática 5/2', category: 'Hidráulico', stock: 8, minStock: 5, unitCost: 120, location: 'Almacén C - Estante 1', supplier: 'Festo' }
  ]);
  readonly workOrders = signal<WorkOrder[]>([
    { id: 'WO-2026-001', title: 'Reemplazo de Bomba Principal', description: 'La bomba presenta fugas y pérdida de presión.', assetId: '35526', priority: 'Alta', status: 'In Progress', assignedTo: 'Carlos M.', dueDate: '2026-03-25', createdAt: '2026-03-20', estimatedHours: 4 },
    { id: 'WO-2026-002', title: 'Mantenimiento Preventivo 500h', description: 'Cambio de filtros y aceite según manual.', assetId: '35527', priority: 'Media', status: 'To Do', assignedTo: 'Ana G.', dueDate: '2026-03-28', createdAt: '2026-03-22', estimatedHours: 2 },
    { id: 'WO-2026-003', title: 'Calibración de Sensores', description: 'Sensores de proximidad descalibrados.', assetId: '35528', priority: 'Baja', status: 'Backlog', dueDate: '2026-04-05', createdAt: '2026-03-23', estimatedHours: 1.5 },
    { id: 'WO-2026-004', title: 'Reparación de Chasis', description: 'Soldadura en soporte lateral derecho.', assetId: '35529', priority: 'Urgente', status: 'Review', assignedTo: 'Luis P.', dueDate: '2026-03-24', createdAt: '2026-03-21', estimatedHours: 6 }
  ]);
  readonly isLoading = signal<boolean>(false);

  // --- Public Read-Only Signals ---
  readonly assets = this.assetsSignal.asReadonly();
  readonly reports = this.reportsSignal.asReadonly();

  // --- Computed Business Intelligence ---
  
  readonly kpiData = computed<KPIData>(() => {
    const totalAssets = this.assetsSignal().length;
    const operativeAssets = this.assetsSignal().filter(a => a.status.name === 'Operativo').length;
    const availability = totalAssets > 0 ? (operativeAssets / totalAssets) * 100 : 100;

    return {
      availability,
      mttr: 4.2, // Mocked for now
      totalCostMonth: 12450,
      budgetMonth: 15000
    };
  });

  readonly safetyStats = signal({
    daysWithoutAccident: 452,
    record: 500,
    announcement: "¡Sigamos así!"
  });

  readonly fleetAvailability = computed(() => {
    const total = this.assetsSignal().length;
    const operative = this.assetsSignal().filter(a => a.status.name === 'Operativo').length;
    const percentage = total > 0 ? Math.round((operative / total) * 100) : 100;
    
    return {
      percentage,
      total,
      operative
    };
  });

  authService = inject(AuthService);
  private unsubscribes: (() => void)[] = [];

  constructor() {
    this.testConnection();
    
    // Initialize Kiosk Mode from LocalStorage
    const savedKiosk = localStorage.getItem('kioskMode');
    if (savedKiosk === 'true') {
      this.isKioskMode.set(true);
    }

    effect(() => {
      if (this.isKioskMode()) this.startKioskRotation();
      else this.stopKioskRotation();
    });

    effect(() => {
      const isReady = this.authService.isAuthReady();
      const user = this.authService.currentUser();
      
      if (isReady && user) {
        this.initFirestoreSync();
      } else {
        this.cleanupListeners();
      }
    });

    // Connectivity Listeners
    window.addEventListener('online', () => this.updateConnectionStatus());
    window.addEventListener('offline', () => this.updateConnectionStatus());
  }

  private cleanupListeners() {
    this.unsubscribes.forEach(unsub => unsub());
    this.unsubscribes = [];
  }

  private async testConnection() {
    try {
      await getDocFromServer(doc(db, 'test', 'connection'));
    } catch (error) {
      if(error instanceof Error && error.message.includes('the client is offline')) {
        console.error("Please check your Firebase configuration. ");
      }
    }
  }

  private handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
    const errInfo: FirestoreErrorInfo = {
      error: error instanceof Error ? error.message : String(error),
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email,
        emailVerified: auth.currentUser?.emailVerified,
        isAnonymous: auth.currentUser?.isAnonymous,
        tenantId: auth.currentUser?.tenantId,
        providerInfo: auth.currentUser?.providerData?.map(provider => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL
        })) || []
      },
      operationType,
      path
    }
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    throw new Error(JSON.stringify(errInfo));
  }

  private initFirestoreSync() {
    this.cleanupListeners(); // Ensure no duplicate listeners

    // Assets Sync
    this.unsubscribes.push(onSnapshot(collection(db, 'assets'), (snapshot) => {
      const assets = snapshot.docs.map(doc => doc.data() as Asset);
      if (assets.length === 0) {
        this.seedInitialData();
      } else {
        this.assetsSignal.set(assets);
      }
    }, (error) => this.handleFirestoreError(error, OperationType.LIST, 'assets')));

    // Reports Sync
    this.unsubscribes.push(onSnapshot(query(collection(db, 'failureReports'), orderBy('entryDate', 'desc')), (snapshot) => {
      this.reportsSignal.set(snapshot.docs.map(doc => doc.data() as FailureReport));
    }, (error) => this.handleFirestoreError(error, OperationType.LIST, 'failureReports')));

    // Active Failures Sync
    this.unsubscribes.push(onSnapshot(query(collection(db, 'activeFailures'), orderBy('fechaIngreso', 'desc')), (snapshot) => {
      this.forkliftFailures.set(snapshot.docs.map(doc => doc.data() as ForkliftFailureEntry));
    }, (error) => this.handleFirestoreError(error, OperationType.LIST, 'activeFailures')));

    // Maintenance Schedule Sync
    this.unsubscribes.push(onSnapshot(collection(db, 'maintenanceSchedule'), (snapshot) => {
      const schedule = snapshot.docs.map(doc => doc.data() as MaintenanceSchedule);
      if (schedule.length === 0 && this.assetsSignal().length > 0) {
        this.seedInitialSchedule();
      } else {
        this.maintenanceSchedule.set(schedule);
      }
    }, (error) => this.handleFirestoreError(error, OperationType.LIST, 'maintenanceSchedule')));
  }

  private async seedInitialData() {
    const initialAssets = hydrateRealAssets(this.statuses);
    for (const asset of initialAssets) {
      try {
        await setDoc(doc(db, 'assets', asset.id), asset);
      } catch (error) {
        this.handleFirestoreError(error, OperationType.WRITE, `assets/${asset.id}`);
      }
    }
  }

  private async seedInitialSchedule() {
    const schedule = this.generateStaticSchedule();
    for (const item of schedule) {
      try {
        await setDoc(doc(db, 'maintenanceSchedule', item.id), item);
      } catch (error) {
        this.handleFirestoreError(error, OperationType.WRITE, `maintenanceSchedule/${item.id}`);
      }
    }
  }

  // --- Configuration Management ---
  
  private updateConnectionStatus() {
     this.connectionStatus.set(navigator.onLine ? 'online' : 'offline');
  }

  // --- Logic & Actions ---

  toggleKioskMode() {
    const newValue = !this.isKioskMode();
    this.isKioskMode.set(newValue);
    // Simulating persistence
    localStorage.setItem('kioskMode', String(newValue));
  }

  private startKioskRotation() {
    if (this.kioskInterval) clearInterval(this.kioskInterval);
    this.kioskInterval = setInterval(() => {
      this.activeSlide.update(current => (current + 1) % 3);
    }, 15000);
  }

  private stopKioskRotation() {
    if (this.kioskInterval) clearInterval(this.kioskInterval);
    this.activeSlide.set(0);
  }

  togglePlantMode() {
    this.plantMode.update(v => !v);
  }

  getAsset(id: string): Asset | undefined {
    return this.assetsSignal().find(a => a.id === id);
  }

  getAssetHistory(assetId: string): FailureReport[] {
    return this.reportsSignal().filter(r => r.assetId === assetId).sort((a, b) => 
      new Date(b.entryDate).getTime() - new Date(a.entryDate).getTime()
    );
  }

  // --- CRUD Operations (Optimistic UI / In-Memory) ---

  async addLiveFailure(entry: Omit<ForkliftFailureEntry, 'id' | 'fechaIngreso' | 'seguimiento'>) {
    const id = 'F-' + Date.now();
    const newEntry: ForkliftFailureEntry = {
      ...entry,
      id: id,
      fechaIngreso: new Date().toISOString(),
      seguimiento: []
    };

    try {
      await setDoc(doc(db, 'activeFailures', id), newEntry);
      await this.syncAssetsWithFailures();
    } catch (error) {
      this.handleFirestoreError(error, OperationType.WRITE, `activeFailures/${id}`);
    }
  }

  async addFailureUpdate(failureId: string, message: string, user: string) {
    const failure = this.forkliftFailures().find(f => f.id === failureId);
    if (!failure) return;

    const update: FailureUpdate = { usuario: user, mensaje: message, fecha: new Date().toISOString() };
    
    try {
      await updateDoc(doc(db, 'activeFailures', failureId), {
        estatus: 'En Proceso',
        seguimiento: [...failure.seguimiento, update]
      });
    } catch (error) {
      this.handleFirestoreError(error, OperationType.UPDATE, `activeFailures/${failureId}`);
    }
  }

  async updateToyotaLogistics(failureId: string, po: string, statusRef: ForkliftFailureEntry['estatusRefaccion'], promiseDate?: string) {
    const updates = { 
      ordenCompra: po, 
      estatusRefaccion: statusRef, 
      fechaPromesa: promiseDate || null, 
      estatus: 'En Proceso' 
    };
    
    try {
      await updateDoc(doc(db, 'activeFailures', failureId), updates);
    } catch (error) {
      this.handleFirestoreError(error, OperationType.UPDATE, `activeFailures/${failureId}`);
    }
  }

  async closeLiveFailure(id: string) {
    const failure = this.forkliftFailures().find(f => f.id === id);
    if (!failure) return;
    
    try {
      await updateDoc(doc(db, 'activeFailures', id), {
        estatus: 'Cerrada',
        fechaSalida: new Date().toISOString()
      });
      await this.syncAssetsWithFailures();
    } catch (error) {
      this.handleFirestoreError(error, OperationType.UPDATE, `activeFailures/${id}`);
    }
  }

  reportFailure(assetId: string, description: string, type: FailureReport['type']) {
    this.addLiveFailure({
      economico: assetId,
      falla: description,
      prioridad: 'Media',
      reporta: 'Operador (App)',
      estatus: 'Abierta'
    });
  }

  private inferFailureType(description: string): FailureReport['type'] {
    const desc = description.toLowerCase();
    if (desc.includes('eléctric')) return 'Eléctrico';
    if (desc.includes('hidráulic')) return 'Hidráulico';
    if (desc.includes('llanta')) return 'Llantas';
    if (desc.includes('motor') || desc.includes('mecánic')) return 'Mecánico';
    if (desc.includes('golpe') || desc.includes('daño')) return 'Estructural';
    if (desc.includes('software') || desc.includes('sensor')) return 'Software';
    return 'Operador';
  }

  async completeRepair(assetId: string, diagnosis: string, cost: number, parts: string[]) {
    const activeFailure = this.forkliftFailures().find(f => f.economico === assetId && f.estatus !== 'Cerrada');
    if (activeFailure) {
      await this.closeLiveFailure(activeFailure.id);
      
      const reportId = `R-${activeFailure.id}`;
      const newReport: FailureReport = {
        id: reportId,
        assetId: assetId,
        entryDate: activeFailure.fechaIngreso,
        exitDate: new Date().toISOString(),
        failureDescription: activeFailure.falla,
        diagnosis: diagnosis,
        partsUsed: parts,
        estimatedCost: cost,
        technician: activeFailure.seguimiento.find(s => s.usuario.includes('Tech'))?.usuario || activeFailure.reporta,
        type: this.inferFailureType(activeFailure.falla)
      };
      
      try {
        await setDoc(doc(db, 'failureReports', reportId), newReport);
      } catch (error) {
        this.handleFirestoreError(error, OperationType.WRITE, `failureReports/${reportId}`);
      }
    }
  }

  async updateAssetsFromExcel(importedData: any[]) {
    this.isLoading.set(true);
    try {
      for (const row of importedData) {
        const id = String(row.Economico || row.ID || '').toUpperCase();
        if (!id) continue;

        const assetRef = doc(db, 'assets', id);
        const assetDoc = await getDoc(assetRef);

        const statusName = row.Estatus || 'Operativo';
        const status = this.statuses.find(s => s.name === statusName) || this.statuses[0];

        const data = {
          brand: row.Marca || row.Brand || 'Toyota',
          model: row.Modelo || row.Model || 'N/A',
          serial: row.Serie || row.Serial || 'N/A',
          status: status,
          statusSince: new Date().toISOString()
        };

        if (assetDoc.exists()) {
          await updateDoc(assetRef, data);
        } else {
          await setDoc(assetRef, { id, ...data });
        }
      }
    } catch (error) {
      this.handleFirestoreError(error, OperationType.WRITE, 'assets/bulk');
    } finally {
      this.isLoading.set(false);
    }
  }

  // --- Maintenance Compliance Actions ---
  
  // Helper to determine status dynamically based on current date
  private evaluateStatus(scheduledDateStr: string, realDateStr?: string, currentStatus?: string): 'Completado' | 'Programado' | 'Vencido' | 'En Proceso' {
    if (realDateStr) return 'Completado';
    if (currentStatus === 'En Proceso') return 'En Proceso';

    const scheduled = new Date(scheduledDateStr);
    scheduled.setHours(0,0,0,0);
    
    const today = new Date();
    today.setHours(0,0,0,0);

    // If scheduled date is strictly less than today and NO real date exists, it is Overdue.
    // If it's today, it's still 'Programado' (due today).
    if (scheduled.getTime() < today.getTime()) return 'Vencido';
    
    return 'Programado';
  }

  async updateMaintenanceDate(id: string, dateStr: string) {
    const item = this.maintenanceSchedule().find(i => i.id === id);
    if (!item) return;

    const prevDate = item.realDate;
    const newStatus = this.evaluateStatus(item.scheduledDate, dateStr, item.status);
    
    const historyRecord: ScheduleHistory = {
       timestamp: new Date().toISOString(),
       user: auth.currentUser?.displayName || 'Supervisor (Sistema)',
       action: dateStr ? 'Registro Ejecución' : 'Corrección',
       previousValue: prevDate ? new Date(prevDate).toLocaleDateString() : 'Pendiente',
       newValue: dateStr ? new Date(dateStr).toLocaleDateString() : 'Sin Fecha'
    };

    const newHistory = [...(item.history || []), historyRecord];

    try {
      await updateDoc(doc(db, 'maintenanceSchedule', id), {
        realDate: dateStr || null,
        status: newStatus,
        history: newHistory
      });
    } catch (error) {
      this.handleFirestoreError(error, OperationType.UPDATE, `maintenanceSchedule/${id}`);
    }
  }

  async updateMaintenanceComments(id: string, comments: string) {
    try {
      await updateDoc(doc(db, 'maintenanceSchedule', id), { comments });
    } catch (error) {
      this.handleFirestoreError(error, OperationType.UPDATE, `maintenanceSchedule/${id}`);
    }
  }

  async updateMaintenanceScheduleFromExcel(importedData: any[]): Promise<{ success: number, errors: string[] }> {
    this.isLoading.set(true);
    const result = this.processExcelData(importedData);
    try {
      for (const item of result.validSchedules) {
        await setDoc(doc(db, 'maintenanceSchedule', item.id), item);
      }
      return { success: result.validSchedules.length, errors: result.errors };
    } catch (error) {
      this.handleFirestoreError(error, OperationType.WRITE, 'maintenanceSchedule/bulk');
      return { success: 0, errors: ['Error al guardar en la base de datos'] };
    } finally {
      this.isLoading.set(false);
    }
  }

  private processExcelData(importedData: any[]) {
    const normalize = (s: string) => s ? s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "") : "";

    const excelDateToJSDate = (serial: number | string) => {
       if (!serial) return null;
       if (typeof serial === 'string') {
          const trimmed = serial.trim();
          if (trimmed.match(/^\d{1,2}\/\d{1,2}\/\d{4}$/)) {
             const [d, m, y] = trimmed.split('/');
             return new Date(parseInt(y), parseInt(m) - 1, parseInt(d));
          }
          if (trimmed.match(/^\d{4}-\d{1,2}-\d{1,2}$/)) {
             return new Date(trimmed);
          }
          const d = new Date(trimmed);
          return isNaN(d.getTime()) ? null : d;
       }
       const utc_days  = Math.floor(serial - 25569);
       const utc_value = utc_days * 86400;                                        
       const date_info = new Date(utc_value * 1000);
       return date_info;
    }

    const errors: string[] = [];
    const validSchedules: MaintenanceSchedule[] = [];

    importedData.forEach((row, index) => {
       const getVal = (targetKeys: string[]) => {
          const normalizedTargets = targetKeys.map(t => normalize(t));
          const rowKeys = Object.keys(row);
          for (const rk of rowKeys) {
              const normalizedRk = normalize(rk);
              if (normalizedTargets.some(t => normalizedRk === t || normalizedRk.includes(t))) {
                  return row[rk];
              }
          }
          return undefined;
       };

       const model = getVal(['modelo', 'model']);
       const serial = getVal(['serie', 'serial']);
       const economico = getVal(['economico', 'id']);
       const smpType = getVal(['smp', 'smptype']);
       const rawScheduledDate = getVal(['fechaprogramada', 'fecha', 'date']);
       const rawRealDate = getVal(['fechareal', 'realdate']);
       const comments = getVal(['notas', 'notes', 'comentarios', 'observaciones', 'comments']);
       
       const missingFields: string[] = [];
       if (!model) missingFields.push('Modelo');
       if (!serial) missingFields.push('Serie');
       if (!economico) missingFields.push('Económico');
       if (!smpType) missingFields.push('SMP');
       if (!rawScheduledDate) missingFields.push('Fecha Programada');

       if (missingFields.length > 0) {
           errors.push(`Fila ${index + 2}: Faltan campos obligatorios (${missingFields.join(', ')})`);
           return;
       }

       let scheduledIso: string;
       let realIso: string | undefined = undefined;
       
       try {
         const d = excelDateToJSDate(rawScheduledDate);
         if (d && !isNaN(d.getTime())) {
             scheduledIso = d.toISOString();
         } else {
             errors.push(`Fila ${index + 2}: Formato de 'Fecha Programada' inválido`);
             return;
         }
       } catch (e) {
         errors.push(`Fila ${index + 2}: Error al procesar fecha programada`);
         return;
       }

       try {
         const d = excelDateToJSDate(rawRealDate);
         if (d && !isNaN(d.getTime())) realIso = d.toISOString();
       } catch (e) {
         // Ignore errors in optional real date
       }
       
       let status: 'Completado' | 'Programado' | 'Vencido' | 'En Proceso';
       if (realIso) {
         status = 'Completado';
       } else {
         status = this.evaluateStatus(scheduledIso);
       }

       const newItem: MaintenanceSchedule = {
         id: `IMP-${Date.now()}-${index}`,
         model: model,
         serial: serial,
         economico: economico,
         supervisor: getVal(['supervisor']) || 'N/A',
         smpType: smpType as any,
         scheduledDate: scheduledIso,
         realDate: realIso,
         duration: getVal(['duracionsmp', 'duracion', 'duration']) || '2hrs',
         otFolio: getVal(['folioot', 'ot', 'otfolio']) || '',
         serviceOrder: getVal(['ordendeserv', 'os', 'serviceorder']) || '',
         hourMeter: getVal(['horometro', 'hourmeter']),
         technician: getVal(['tecnicoreal', 'tecnico', 'technician']) || 'Por asignar',
         status: status,
         history: [], 
         comments: comments || ''
       };

       validSchedules.push(newItem);
    });

    return { validSchedules, errors };
  }

  // --- Sync Helpers ---
  private async syncAssetsWithFailures() {
    const failures = this.forkliftFailures();
    const activeFailures = failures.filter(f => f.estatus !== 'Cerrada');
    const activeIds = new Set(activeFailures.map(f => f.economico));
    const activeFailureMap = new Map(activeFailures.map(f => [f.economico, f]));
    
    const tallerStatus = this.statuses.find(s => s.name === 'Taller')!;
    const opStatus = this.statuses.find(s => s.name === 'Operativo')!;

    const assets = this.assetsSignal();
    for (const a of assets) {
      let updatedAsset: Partial<Asset> | null = null;
      if (activeIds.has(a.id)) {
        if (a.status.name !== 'Taller') {
          updatedAsset = { 
            status: tallerStatus, 
            statusSince: activeFailureMap.get(a.id)?.fechaIngreso || new Date().toISOString(), 
            lastFailure: activeFailureMap.get(a.id)?.falla 
          };
        }
      } else if (a.status.name === 'Taller' && !activeIds.has(a.id)) {
        updatedAsset = { 
          status: opStatus, 
          statusSince: new Date().toISOString(), 
          lastFailure: undefined 
        };
      }

      if (updatedAsset) {
        try {
          await updateDoc(doc(db, 'assets', a.id), updatedAsset);
        } catch (error) {
          this.handleFirestoreError(error, OperationType.UPDATE, `assets/${a.id}`);
        }
      }
    }
  }

  // --- MOCK DATA GENERATORS ---

  // REPLACED DYNAMIC MOCK WITH STATIC SCHEDULE MATCHING IMAGE
  private generateStaticSchedule(): MaintenanceSchedule[] {
    // Data extracted from the physical image provided by the user.
    // Base is constant, statuses update dynamically.
    const staticData = [
        { model: "7FB25", serial: "60504", eco: "CUA-25436", smp: "REV", date: "2026-02-05", tech: "Erick Ramon", ot: "MXOT184269" },
        { model: "8FGU30", serial: "66755", eco: "CUA-25097", smp: "REV", date: "2026-02-12", tech: "Ariel Alavez", ot: "MXOT184270" },
        { model: "32-8FG30", serial: "63040", eco: "CUA-26786", smp: "REV", date: "2026-02-14", tech: "Maycol Martinez", ot: "MXOT184283" },
        { model: "32-8FG30", serial: "66455", eco: "CUA-29438", smp: "REV", date: "2026-02-14", tech: "Erick Ramon", ot: "MXOT184285" },
        { model: "32-8FG30", serial: "66454", eco: "CUA-29440", smp: "REV", date: "2026-02-05", tech: "Maycol Martinez", ot: "MXOT184286" },
        { model: "32-8FG30", serial: "92719", eco: "CUA-35526", smp: "Z", date: "2026-02-14", tech: "Ariel Alavez", ot: "MXOT184289" },
        { model: "32-8FG30", serial: "92714", eco: "CUA-35482", smp: "X", date: "2026-02-05", tech: "Max Gonzalo", ot: "MXOT184291" },
        { model: "32-8FG30", serial: "92730", eco: "CUA-35483", smp: "X", date: "2026-02-05", tech: "Ariel Alavez", ot: "MXOT184293" },
        { model: "32-8FG30", serial: "92732", eco: "CUA-35494", smp: "X", date: "2026-02-08", tech: "Erick Ramon", ot: "MXOT184294" },
        { model: "32-8FG30", serial: "95159", eco: "CUA-37191", smp: "X", date: "2026-02-07", tech: "Maycol Martinez", ot: "MXOT184296" },
        { model: "32-8FG30", serial: "95162", eco: "CUA-37192", smp: "X", date: "2026-02-07", tech: "Ariel Alavez", ot: "MXOT184297" },
        { model: "32-8FG30", serial: "95074", eco: "CUA-37193", smp: "X", date: "2026-02-07", tech: "Max Gonzalo", ot: "MXOT184298" },
        { model: "32-8FG30", serial: "95056", eco: "CUA-37194", smp: "X", date: "2026-02-08", tech: "Erick Ramon", ot: "MXOT184299" },
        { model: "32-8FG30", serial: "95049", eco: "CUA-37195", smp: "X", date: "2026-02-08", tech: "Ariel Alavez", ot: "MXOT184300" },
        { model: "32-8FG30", serial: "97520", eco: "CUA-40019", smp: "REV", date: "2026-02-12", tech: "Max Gonzalo", ot: "MXOT184303" },
        { model: "32-8FG30", serial: "97519", eco: "CUA-40020", smp: "Y", date: "2026-02-12", tech: "Ariel Alavez", ot: "MXOT184304" },
        { model: "32-8FG30", serial: "97532", eco: "CUA-40021", smp: "Y", date: "2026-02-11", tech: "Erick Ramon", ot: "MXOT184307" },
        { model: "32-8FG30", serial: "97518", eco: "CUA-40057", smp: "Y", date: "2026-02-07", tech: "Maycol Martinez", ot: "MXOT184310" },
        { model: "32-8FG30", serial: "97529", eco: "CUA-40060", smp: "Y", date: "2026-02-07", tech: "Ariel Alavez", ot: "MXOT184313" },
        { model: "32-8FG30", serial: "97560", eco: "CUA-40065", smp: "REV", date: "2026-02-09", tech: "Max Gonzalo", ot: "MXOT184314" },
        { model: "32-8FG30", serial: "97562", eco: "CUA-40327", smp: "REV", date: "2026-02-09", tech: "Erick Ramon", ot: "MXOT184315" },
        { model: "32-8FG30", serial: "97584", eco: "CUA-40328", smp: "REV", date: "2026-02-09", tech: "Ariel Alavez", ot: "MXOT184318" },
        { model: "32-8FG30", serial: "97781", eco: "CUA-40338", smp: "Z", date: "2026-02-14", tech: "Maycol Martinez", ot: "MXOT184321" },
        { model: "32-8FG30", serial: "97788", eco: "CUA-40066", smp: "X", date: "2026-02-10", tech: "Erick Ramon", ot: "MXOT184322" },
        { model: "32-8FG30", serial: "97796", eco: "CUA-40067", smp: "REV", date: "2026-02-14", tech: "Ariel Alavez", ot: "MXOT184324" },
        { model: "8FGU30", serial: "35540", eco: "BACK-UP", smp: "REV", date: "2026-02-12", tech: "Maycol Martinez", ot: "MXOT184326" },
        { model: "8FBCU30", serial: "67022", eco: "RENTA", smp: "REV", date: "2026-02-05", tech: "Erick Ramon", ot: "MXOT184327" }
      ];

    return staticData.map((item, index) => {
      const scheduledIso = new Date(item.date).toISOString(); // Using static date
      const status = this.evaluateStatus(scheduledIso);
      
      return {
        id: `SCH-${index}`,
        model: item.model,
        serial: item.serial,
        economico: item.eco,
        supervisor: "AARON VELAZQUEZ",
        smpType: item.smp as any,
        scheduledDate: scheduledIso,
        realDate: undefined,
        duration: "2hrs",
        otFolio: item.ot,
        serviceOrder: `OS-${237000 + index}`,
        hourMeter: undefined,
        technician: item.tech,
        status: status,
        history: [], 
        comments: '' // Default empty comments
      };
    });
  }
}