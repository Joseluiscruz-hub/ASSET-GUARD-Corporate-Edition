import { Component, signal, effect, inject, computed } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { DataService } from './services/data.service';
import { GeminiService } from './services/gemini.service';
import { AuthService } from './services/auth.service';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AssetListComponent } from './components/admin/asset-list.component';
import { AssetDetailComponent } from './components/asset-detail/asset-detail.component';
import { AdminComponent } from './components/admin/admin.component';
import { ServicePanelComponent } from './components/service-panel.component';
import { SolicitorPanelComponent } from './solicitor-panel/solicitor-panel.component';
import { MaintenanceComplianceComponent } from './components/maintenance-compliance/maintenance-compliance.component';
import { InventoryComponent } from './components/inventory/inventory.component';
import { WorkOrdersComponent } from './components/work-orders/work-orders.component';

type View = 'dashboard' | 'assets' | 'service' | 'solicitor' | 'settings' | 'compliance' | 'inventory' | 'work-orders';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule, 
    DatePipe,
    DashboardComponent, 
    AssetListComponent, 
    AssetDetailComponent, 
    AdminComponent, 
    ServicePanelComponent,
    SolicitorPanelComponent,
    MaintenanceComplianceComponent,
    InventoryComponent,
    WorkOrdersComponent
  ],
  templateUrl: './app.component.html',
  styles: [`
    .fade-enter { animation: fadeIn 0.3s ease-out forwards; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
  `]
})
export class AppComponent {
  dataService = inject(DataService);
  geminiService = inject(GeminiService);
  authService = inject(AuthService);

  // State
  currentView = signal<View>('dashboard');
  selectedAssetId = signal<string | null>(null);
  showAiPanel = signal(false);
  
  // Auth Signals
  user = this.authService.currentUser;
  userProfile = this.authService.userProfile;
  isAuthReady = this.authService.isAuthReady;
  
  // Data Signals
  connectionStatus = this.dataService.connectionStatus;
  lastUpdate = this.dataService.lastUpdate;
  plantMode = this.dataService.plantMode;
  failures = this.dataService.forkliftFailures;

  // AI Insights State
  aiInsights = signal<string | null>(null);
  aiLoading = signal(false);

  private previousFailureCount = 0;

  // Derived
  syncText = computed(() => {
     if (this.connectionStatus() === 'online') return 'Conectado (Firebase Firestore)';
     if (this.connectionStatus() === 'syncing') return 'Sincronizando...';
     return 'Modo Offline (Solo Lectura)';
  });

  constructor() {
    // Notification Effect
    effect(() => {
      const list = this.failures();
      if (list.length > this.previousFailureCount) {
        const latest = list[0];
        if (latest.estatus === 'Abierta' && this.previousFailureCount > 0) {
           this.playAlert(latest.prioridad === 'Alta');
        }
      }
      this.previousFailureCount = list.length;
    });

    // Custom Events
    window.addEventListener('asset-selected', (e: any) => this.selectedAssetId.set(e.detail));
    window.addEventListener('asset-closed', () => this.selectedAssetId.set(null));
  }

  login() {
    this.authService.login();
  }

  logout() {
    this.authService.logout();
  }

  // Navigation Logic
  setView(view: View) {
    this.currentView.set(view);
    this.selectedAssetId.set(null);
    // Auto-switch theme based on view context
    if (view === 'dashboard' && !this.plantMode()) this.dataService.togglePlantMode();
    if (view !== 'dashboard' && this.plantMode()) this.dataService.togglePlantMode();
  }

  toggleAiPanel() {
    this.showAiPanel.update(v => !v);
    if (this.showAiPanel() && !this.aiInsights()) {
      // Don't auto-generate, let user choose action
    }
  }

  async generateExecutiveSummary() {
    this.aiLoading.set(true);
    const kpi = this.dataService.kpiData();
    const availability = this.dataService.fleetAvailability();
    const active = this.failures().filter(f => f.estatus !== 'Cerrada');
    
    const summary = await this.geminiService.generateExecutiveReport(kpi, active, availability);
    this.aiInsights.set(summary);
    this.aiLoading.set(false);
  }

  playAlert(critical: boolean) {
    const audio = new Audio(critical 
      ? 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' 
      : 'https://assets.mixkit.co/active_storage/sfx/2345/2345-preview.mp3');
    audio.play().catch(() => {});
  }

  get viewTitle(): string {
    switch(this.currentView()) {
      case 'dashboard': return 'Dashboard Corporativo';
      case 'compliance': return 'Programa SMP';
      case 'assets': return 'Gestión de Activos';
      case 'service': return 'Panel de Servicio Técnico';
      case 'solicitor': return 'App Operador';
      case 'inventory': return 'Inventario y Refacciones';
      case 'work-orders': return 'Órdenes de Trabajo';
      case 'settings': return 'Configuración';
      default: return 'AssetGuard';
    }
  }

  get viewSubtitle(): string {
    switch(this.currentView()) {
      case 'dashboard': return 'KPIs de disponibilidad, seguridad y costos en tiempo real.';
      case 'compliance': return 'Seguimiento del programa de mantenimiento sistemático.';
      case 'assets': return 'Listado maestro, ubicación y estado de toda la flota.';
      case 'service': return 'Administración de órdenes de trabajo, refacciones y técnicos.';
      case 'inventory': return 'Control de stock, costos y alertas de reabastecimiento.';
      case 'work-orders': return 'Gestión visual de tareas de mantenimiento y asignaciones.';
      case 'settings': return 'Administración del sistema y conexiones.';
      default: return '';
    }
  }
}