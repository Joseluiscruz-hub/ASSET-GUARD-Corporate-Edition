
import { Injectable } from '@angular/core';
import { GoogleGenAI } from "@google/genai";
import { FailureReport, Asset } from '../types';

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  
  async analyzeMaintenanceHistory(asset: Asset, history: FailureReport[]): Promise<string> {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const prompt = `
        Actúa como un Ingeniero Senior de Mantenimiento y Confiabilidad.
        Analiza el siguiente historial de mantenimiento del equipo ${asset.brand} ${asset.model} (ID: ${asset.id}).
        
        Datos del historial:
        ${JSON.stringify(history.map(h => ({
          fecha: h.entryDate,
          falla: h.failureDescription,
          tipo: h.type,
          costo: h.estimatedCost
        })))}

        Por favor provee un "Diagnóstico Predictivo" corto y conciso (máximo 2 párrafos) y una lista de 3 "Acciones Recomendadas" para evitar futuras fallas.
        Formato de salida deseado en HTML simple (sin markdown block, solo tags <p>, <ul>, <li>, <strong>).
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      return response.text || '<p>No se pudo generar el análisis.</p>';
    } catch (error) {
      console.error('Gemini Error:', error);
      return '<p class="text-red-500">Error conectando con el servicio de IA. Verifique su conexión.</p>';
    }
  }
}
