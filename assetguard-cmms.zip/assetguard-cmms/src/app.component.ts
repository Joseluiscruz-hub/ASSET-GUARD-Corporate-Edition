
import { Component, signal, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AssetListComponent } from './components/asset-list/asset-list.component';
import { AssetDetailComponent } from './components/asset-detail/asset-detail.component';
import { AdminComponent } from './components/admin/admin.component';

type View = 'dashboard' | 'assets' | 'settings';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, DashboardComponent, AssetListComponent, AssetDetailComponent, AdminComponent],
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit {
  currentView = signal<View>('dashboard');
  selectedAssetId = signal<string | null>(null);

  ngOnInit() {
    // Listen for custom events for navigation from child components
    window.addEventListener('asset-selected', (e: any) => {
      this.selectedAssetId.set(e.detail);
    });
    
    window.addEventListener('asset-closed', () => {
      this.selectedAssetId.set(null);
    });
  }

  setView(view: View) {
    this.currentView.set(view);
    this.selectedAssetId.set(null); // Clear selection when changing main tabs
  }
}
