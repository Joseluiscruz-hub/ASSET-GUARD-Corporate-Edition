import { Injectable, signal, computed } from '@angular/core';
import { Asset, FailureReport, Status, KPIData } from '../types';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  // --- Master Catalogs ---
  readonly statuses: Status[] = [
    { id: '1', name: 'Operativo', color: 'bg-green-100 text-green-800', hex: '#22c55e' },
    { id: '2', name: 'Taller', color: 'bg-red-100 text-red-800', hex: '#ef4444' },
    { id: '3', name: 'Preventivo', color: 'bg-yellow-100 text-yellow-800', hex: '#eab308' },
    { id: '4', name: 'Baja', color: 'bg-gray-100 text-gray-800', hex: '#6b7280' },
  ];

  // --- State Signals ---
  private assetsSignal = signal<Asset[]>(this.generateMockAssets());
  private reportsSignal = signal<FailureReport[]>(this.generateMockReports());

  // --- Public Signals (Read Only) ---
  readonly assets = this.assetsSignal.asReadonly();
  readonly reports = this.reportsSignal.asReadonly();

  // --- Computed KPIs ---
  readonly kpiData = computed<KPIData>(() => {
    const totalAssets = this.assetsSignal().length;
    const operativeAssets = this.assetsSignal().filter(a => a.status.name === 'Operativo').length;
    
    // MTTR Calculation (Mean Time To Repair in Hours)
    const closedReports = this.reportsSignal().filter(r => r.exitDate);
    let totalRepairHours = 0;
    closedReports.forEach(r => {
      const start = new Date(r.entryDate).getTime();
      const end = new Date(r.exitDate!).getTime();
      totalRepairHours += (end - start) / (1000 * 60 * 60);
    });
    const mttr = closedReports.length > 0 ? totalRepairHours / closedReports.length : 0;

    // Costs
    const currentMonth = new Date().getMonth();
    const monthlyCost = this.reportsSignal()
      .filter(r => new Date(r.entryDate).getMonth() === currentMonth)
      .reduce((acc, curr) => acc + curr.estimatedCost, 0);

    return {
      availability: totalAssets > 0 ? (operativeAssets / totalAssets) * 100 : 0,
      mttr: Math.round(mttr * 10) / 10,
      totalCostMonth: monthlyCost,
      budgetMonth: 15000 // Mock budget
    };
  });

  // --- Methods ---
  getAsset(id: string): Asset | undefined {
    return this.assetsSignal().find(a => a.id === id);
  }

  getAssetHistory(assetId: string): FailureReport[] {
    return this.reportsSignal().filter(r => r.assetId === assetId).sort((a, b) => 
      new Date(b.entryDate).getTime() - new Date(a.entryDate).getTime()
    );
  }

  // --- CRUD Actions (Simulating Cloud Functions) ---

  // 1. Registrar Falla (Entrada a Taller)
  reportFailure(assetId: string, description: string, type: FailureReport['type']) {
    const asset = this.getAsset(assetId);
    if (!asset) return;

    // Update Asset Status
    const tallerStatus = this.statuses.find(s => s.name === 'Taller')!;
    
    this.assetsSignal.update(assets => assets.map(a => {
      if (a.id === assetId) {
        return { 
          ...a, 
          status: tallerStatus, 
          statusSince: new Date().toISOString(),
          lastFailure: description
        };
      }
      return a;
    }));

    // Create Open Report
    const newReport: FailureReport = {
      id: `R-${Math.floor(Math.random() * 10000)}`,
      assetId: assetId,
      entryDate: new Date().toISOString(),
      exitDate: null,
      failureDescription: description,
      partsUsed: [],
      estimatedCost: 0,
      technician: 'Pendiente',
      type: type
    };

    this.reportsSignal.update(reports => [newReport, ...reports]);
  }

  // 2. Finalizar Reparación (Salida de Taller)
  completeRepair(assetId: string, diagnosis: string, cost: number, parts: string[]) {
    const asset = this.getAsset(assetId);
    if (!asset) return;

    // Find active report
    const activeReport = this.reportsSignal().find(r => r.assetId === assetId && !r.exitDate);

    // Update Report
    if (activeReport) {
      this.reportsSignal.update(reports => reports.map(r => {
        if (r.id === activeReport.id) {
          return {
            ...r,
            exitDate: new Date().toISOString(),
            diagnosis,
            estimatedCost: cost,
            partsUsed: parts,
            technician: 'Usuario Actual' // Mock user
          };
        }
        return r;
      }));
    }

    // Update Asset Status back to Operativo
    const opStatus = this.statuses.find(s => s.name === 'Operativo')!;
    
    this.assetsSignal.update(assets => assets.map(a => {
      if (a.id === assetId) {
        return { 
          ...a, 
          status: opStatus, 
          statusSince: new Date().toISOString()
        };
      }
      return a;
    }));
  }
  
  // 3. Importación Masiva (Excel Sync)
  updateAssetsFromExcel(importedData: any[]) {
    this.assetsSignal.update(currentAssets => {
      // Create a map of current assets for easy lookup
      // FIX: Explicitly type the Map to avoid inference issues causing 'unknown' type errors
      const assetMap = new Map<string, Asset>();
      currentAssets.forEach(a => assetMap.set(a.id, a));
      
      importedData.forEach(row => {
        const id = row.Economico || row.id;
        if (!id) return;

        // Map String Status to Object
        let statusObj = this.statuses.find(s => s.name === row.Estatus) || this.statuses[0]; // Default Operativo
        
        // Calculate statusSince or use provided date
        let statusSince = new Date().toISOString();
        const existing = assetMap.get(id);

        if (row.fechaIngreso) {
          // If fechaIngreso exists, use it. (Assuming component converted it to valid format)
          statusSince = row.fechaIngreso;
        } else {
           // If asset exists and status hasn't changed, keep old statusSince
           if (existing && existing.status.name === statusObj.name) {
             statusSince = existing.statusSince;
           }
        }

        const updatedAsset: Asset = {
          id: id,
          brand: row.Marca || existing?.brand || 'Generico',
          model: row.Modelo || existing?.model || 'S/M',
          serial: existing?.serial || `SN-${id}`,
          acquisitionDate: existing?.acquisitionDate || '2020-01-01',
          fuelType: existing?.fuelType || 'Gas LP',
          location: existing?.location || 'Planta',
          critical: existing?.critical || false,
          
          status: statusObj,
          statusSince: statusSince,
          lastFailure: row.Falla || existing?.lastFailure
        };
        
        assetMap.set(id, updatedAsset);
      });

      return Array.from(assetMap.values());
    });
  }


  // --- Mock Data Generators ---
  private generateMockAssets(): Asset[] {
    const brands = ['Toyota', 'Yale', 'Hyster', 'Crown'];
    const models = ['8FGCU25', 'GLP050', 'S50FT', 'C-5'];
    
    return Array.from({ length: 12 }, (_, i) => {
      const statusIdx = Math.random() > 0.7 ? (Math.random() > 0.5 ? 1 : 2) : 0; // Bias towards Operativo (0)
      const status = this.statuses[statusIdx];
      
      let statusSince = new Date();
      if (status.name === 'Taller') {
         const daysAgo = Math.random() > 0.5 ? 5 : 1;
         statusSince.setDate(statusSince.getDate() - daysAgo);
      }

      return {
        id: `M-${100 + i}`,
        brand: brands[i % 4],
        model: models[i % 4],
        serial: `SN-${202300 + i}`,
        acquisitionDate: '2020-05-15',
        fuelType: i % 3 === 0 ? 'Eléctrico' : 'Gas LP',
        status: status,
        statusSince: statusSince.toISOString(),
        location: `Pasillo ${Math.floor(Math.random() * 10) + 1}`,
        critical: Math.random() > 0.8, // 20% critical assets
        lastFailure: i % 3 === 0 ? 'Manguera Rota' : undefined
      };
    });
  }

  private generateMockReports(): FailureReport[] {
    const failures = [
      { desc: 'Fuga aceite hidráulico', type: 'Hidráulico', cost: 1200 },
      { desc: 'Batería no retiene carga', type: 'Eléctrico', cost: 4500 },
      { desc: 'Desgaste excesivo llantas', type: 'Llantas', cost: 800 },
      { desc: 'Motor de arranque fallando', type: 'Eléctrico', cost: 1500 },
      { desc: 'Golpe en contrapeso', type: 'Operador', cost: 300 },
    ] as const;

    const reports: FailureReport[] = [];
    
    for (let i = 0; i < 30; i++) {
      const failure = failures[Math.floor(Math.random() * failures.length)];
      reports.push({
        id: `R-${5000 + i}`,
        assetId: `M-${100 + (i % 12)}`,
        entryDate: new Date(2023, 10, i + 1).toISOString(),
        exitDate: new Date(2023, 10, i + 3).toISOString(),
        failureDescription: failure.desc,
        diagnosis: 'Reemplazo de componentes dañados y pruebas operativas.',
        partsUsed: ['O-Ring Kit', 'Filtro', 'Aceite 10W30'],
        estimatedCost: failure.cost,
        technician: 'Juan Pérez',
        type: failure.type
      });
    }
    return reports;
  }
}