
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from '../../services/data.service';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-8 max-w-4xl mx-auto">
      <div class="border-b border-gray-100 pb-6 mb-6">
        <h2 class="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <i class="fas fa-file-excel text-green-600"></i>
          Carga Masiva de Flota
        </h2>
        <p class="text-gray-500 mt-2">
          Utilice este módulo para sincronizar el estatus de la flota mediante archivos Excel para auditorías.
        </p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- Actions Area -->
        <div class="space-y-6">
          <div class="bg-blue-50 p-6 rounded-lg border border-blue-100">
            <h3 class="font-bold text-blue-900 mb-2">1. Descargar Plantilla</h3>
            <p class="text-sm text-blue-700 mb-4">
              Obtenga el formato correcto con la pestaña "Montacargas" pre-configurada.
            </p>
            <button (click)="downloadTemplate()" class="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium transition flex items-center justify-center gap-2">
              <i class="fas fa-download"></i> Descargar Plantilla
            </button>
          </div>

          <div class="bg-gray-50 p-6 rounded-lg border border-gray-200">
             <h3 class="font-bold text-gray-800 mb-2">2. Subir Archivo</h3>
             <p class="text-sm text-gray-600 mb-4">
               Asegúrese que la hoja se llame <strong>Montacargas</strong>.
             </p>
             
             <div class="relative border-2 border-dashed border-gray-300 rounded-lg p-6 hover:bg-gray-100 transition text-center cursor-pointer">
                <input type="file" (change)="onFileChange($event)" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept=".xlsx, .xls">
                <i class="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-2"></i>
                <p class="text-sm font-medium text-gray-600">Arrastre o seleccione archivo</p>
             </div>
             
             @if (uploadStatus()) {
               <div class="mt-4 p-3 rounded bg-green-100 text-green-700 text-sm font-bold flex items-center gap-2">
                 <i class="fas fa-check"></i> {{ uploadStatus() }}
               </div>
             }
             @if (errorStatus()) {
                <div class="mt-4 p-3 rounded bg-red-100 text-red-700 text-sm font-bold flex items-center gap-2">
                  <i class="fas fa-times-circle"></i> {{ errorStatus() }}
                </div>
             }
          </div>
        </div>

        <!-- Instructions -->
        <div class="prose prose-sm text-gray-600">
          <h3 class="text-lg font-bold text-gray-800">Instrucciones de Auditoría</h3>
          <ul class="list-disc pl-4 space-y-2 mt-4">
            <li>El archivo debe contener una pestaña llamada <strong>Montacargas</strong>.</li>
            <li>
              <strong>Columnas requeridas:</strong>
              <ul class="list-circle pl-4 mt-1 text-xs font-mono bg-gray-50 p-2 rounded">
                <li>Economico (ID)</li>
                <li>Marca</li>
                <li>Modelo</li>
                <li>Estatus (Operativo/Taller/Preventivo)</li>
                <li>Falla (Opcional)</li>
                <li>fechaIngreso (Fecha de entrada a taller)</li>
              </ul>
            </li>
            <li>Al cargar, el sistema calculará automáticamente los <strong>días detenido</strong> si el estatus es "Taller".</li>
            <li>Los datos se sincronizarán inmediatamente en el Dashboard de Auditoría.</li>
          </ul>
        </div>
      </div>
    </div>
  `
})
export class AdminComponent {
  private dataService = inject(DataService);
  uploadStatus = signal<string | null>(null);
  errorStatus = signal<string | null>(null);

  downloadTemplate() {
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet([
      { Economico: 'M-101', Marca: 'Toyota', Modelo: '8FGCU25', Estatus: 'Operativo', Falla: '', fechaIngreso: '' },
      { Economico: 'M-102', Marca: 'Yale', Modelo: 'GLP050', Estatus: 'Taller', Falla: 'Fuga aceite', fechaIngreso: '2023-10-25' },
    ]);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Montacargas');
    XLSX.writeFile(wb, 'Plantilla_Auditoria_Flota.xlsx');
  }

  onFileChange(evt: any) {
    this.uploadStatus.set(null);
    this.errorStatus.set(null);

    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) {
      this.errorStatus.set('No se puede usar múltiples archivos.');
      return;
    }

    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      try {
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

        const sheetName = 'Montacargas';
        if (!wb.Sheets[sheetName]) {
          this.errorStatus.set(`No se encontró la pestaña "${sheetName}".`);
          return;
        }

        const ws: XLSX.WorkSheet = wb.Sheets[sheetName];
        const data: any[] = XLSX.utils.sheet_to_json(ws);

        if (data.length > 0) {
            this.processData(data);
            this.uploadStatus.set(`Se actualizaron ${data.length} registros exitosamente.`);
        } else {
            this.errorStatus.set('La hoja está vacía.');
        }

      } catch (err) {
        console.error(err);
        this.errorStatus.set('Error al procesar el archivo.');
      }
    };
    reader.readAsBinaryString(target.files[0]);
  }

  processData(data: any[]) {
    // Basic sanitization if needed, converting Excel dates
    const processed = data.map(row => {
        // Handle Excel Date serial numbers if necessary, but assuming standard strings or date inputs for now
        // If fechaIngreso is a number (Excel serial date)
        if (typeof row.fechaIngreso === 'number') {
            const date = new Date((row.fechaIngreso - (25567 + 2)) * 86400 * 1000); // Simple conversion
            row.fechaIngreso = date.toISOString();
        }
        return row;
    });

    this.dataService.updateAssetsFromExcel(processed);
  }
}
