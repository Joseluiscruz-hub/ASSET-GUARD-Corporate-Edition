import { Component, inject, computed } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-service-panel',
  standalone: true,
  imports: [CommonModule, DatePipe, FormsModule],
  template: `
    <div class="space-y-6">
       
       <!-- Header Stats -->
       <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div class="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 flex items-center gap-4">
             <div class="w-12 h-12 rounded-full bg-orange-100 dark:bg-orange-500/20 text-orange-600 dark:text-orange-300 flex items-center justify-center">
                <i class="fas fa-wrench text-xl"></i>
             </div>
             <div>
                <p class="text-xs text-slate-500 uppercase font-bold">Unidades en Taller</p>
                <p class="text-2xl font-black text-slate-800 dark:text-white">{{ openFailures().length }}</p>
             </div>
          </div>
          <div class="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 flex items-center gap-4">
            <div class="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-600 dark:text-purple-300 flex items-center justify-center">
                <i class="fas fa-box-open text-xl"></i>
             </div>
             <div>
                <p class="text-xs text-slate-500 uppercase font-bold">Refacciones Pendientes</p>
                <p class="text-2xl font-black text-slate-800 dark:text-white">{{ pendingParts() }}</p>
             </div>
          </div>
           <div class="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 flex items-center gap-4">
            <div class="w-12 h-12 rounded-full bg-red-100 dark:bg-red-500/20 text-red-600 dark:text-red-300 flex items-center justify-center">
                <i class="fas fa-exclamation-triangle text-xl"></i>
             </div>
             <div>
                <p class="text-xs text-slate-500 uppercase font-bold">Prioridad Alta</p>
                <p class="text-2xl font-black text-slate-800 dark:text-white">{{ criticalCount() }}</p>
             </div>
          </div>
       </div>

       <!-- Main Content -->
       <div class="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden min-h-[500px]">
          <div class="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/30 flex justify-between items-center">
             <h3 class="font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wide text-sm">Órdenes de Trabajo Activas</h3>
          </div>

          <div class="divide-y divide-slate-100 dark:divide-slate-700/50">
             @for (f of openFailures(); track f.id) {
                <div class="p-6 hover:bg-slate-50/50 dark:hover:bg-slate-900/20 transition-colors">
                   
                   <!-- Top Row: ID + Status -->
                   <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
                      <div class="flex items-center gap-4">
                         <div class="w-12 h-12 rounded-lg bg-slate-800 text-white flex items-center justify-center font-black text-lg shadow-inner">
                            {{ f.economico.slice(-3) }}
                         </div>
                         <div>
                            <h4 class="font-black text-xl text-slate-800 dark:text-white">{{ f.economico }}</h4>
                            <p class="text-xs text-slate-500 font-mono">{{ f.fechaIngreso | date:'medium' }}</p>
                         </div>
                      </div>
                      
                      <div class="flex gap-2">
                         <span [class]="'px-3 py-1 rounded text-xs font-bold uppercase border ' + getPriorityBadgeClass(f.prioridad)">
                            {{ f.prioridad }}
                         </span>
                         <span class="px-3 py-1 rounded text-xs font-bold uppercase border bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-500/10 dark:text-blue-300 dark:border-blue-500/30">
                            {{ f.estatus }}
                         </span>
                      </div>
                   </div>

                   <!-- Diagnosis & Form -->
                   <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      <!-- Left: Diagnosis & History -->
                      <div class="lg:col-span-1 space-y-4">
                         <div>
                           <p class="text-xs font-bold text-slate-400 uppercase mb-2">Diagnóstico Reportado</p>
                           <div class="bg-slate-50 dark:bg-slate-900/50 p-3 rounded-lg border border-slate-200 dark:border-slate-700 text-sm text-slate-700 dark:text-slate-300 font-medium">
                              {{ f.falla }}
                           </div>
                         </div>
                         <div>
                            <p class="text-xs font-bold text-slate-400 uppercase mb-2">Bitácora Técnica</p>
                            <div class="space-y-2 max-h-32 overflow-y-auto custom-scroll text-xs p-1">
                               @for (msg of f.seguimiento; track msg.fecha) {
                                  <div class="p-2 rounded bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                                     <span class="font-bold text-orange-600 dark:text-orange-400">{{ msg.usuario }}:</span> 
                                     <span class="text-slate-600 dark:text-slate-300">{{ msg.mensaje }}</span>
                                  </div>
                               } @empty {
                                 <div class="text-center italic text-slate-400 py-4 text-xs">Sin notas técnicas.</div>
                               }
                            </div>
                         </div>
                      </div>

                      <!-- Right: Logistics & Actions -->
                      <div class="lg:col-span-2 bg-slate-50 dark:bg-slate-900/50 rounded-xl p-5 border border-slate-200 dark:border-slate-700">
                         <h5 class="font-bold text-slate-700 dark:text-slate-200 mb-4 flex items-center gap-2">
                            <i class="fas fa-box-open"></i> Logística de Refacciones
                         </h5>
                         
                         <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                               <label class="text-xs font-bold text-slate-400 uppercase">Orden de Compra (PO)</label>
                               <input type="text" #po [value]="f.ordenCompra || ''" class="w-full mt-1 p-2 rounded border border-slate-300 dark:border-slate-600 text-sm focus:ring-2 focus:ring-orange-500 bg-white dark:bg-slate-800">
                            </div>
                             <div>
                               <label class="text-xs font-bold text-slate-400 uppercase">Estatus Refacción</label>
                               <select #status [value]="f.estatusRefaccion || 'N/A'" class="w-full mt-1 p-2 rounded border border-slate-300 dark:border-slate-600 text-sm bg-white dark:bg-slate-800">
                                  <option>N/A (Solo Mano de Obra)</option>
                                  <option>En Stock</option>
                                  <option>Pedida</option>
                                  <option>Por Recibir</option>
                               </select>
                            </div>
                         </div>
                         
                         <div class="flex gap-2 mt-4">
                            <input #note type="text" placeholder="Agregar nota técnica..." class="flex-1 p-2 rounded border border-slate-300 dark:border-slate-600 text-sm bg-white dark:bg-slate-800">
                            <button (click)="addNote(f.id, note.value); note.value=''" class="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded text-xs hover:bg-slate-300 dark:hover:bg-slate-600 transition">
                               <i class="fas fa-comment"></i>
                            </button>
                         </div>
                         
                         <div class="flex gap-3 mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                            <button (click)="saveLogistics(f.id, po.value, status.value)" class="flex-1 py-2 bg-slate-800 text-white rounded font-bold text-xs uppercase hover:bg-slate-900 transition shadow">
                               Guardar Cambios
                            </button>
                            <button (click)="closeTicket(f.id)" class="px-6 py-2 bg-emerald-600 text-white rounded font-bold text-xs uppercase hover:bg-emerald-700 transition shadow">
                               Liberar Equipo
                            </button>
                         </div>
                      </div>
                   </div>
                </div>
             } @empty {
                <div class="py-20 text-center">
                   <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-300 dark:text-slate-500 mb-4">
                      <i class="fas fa-check text-4xl"></i>
                   </div>
                   <h3 class="font-bold text-slate-600 dark:text-slate-200">Todo en Orden</h3>
                   <p class="text-slate-400 text-sm">No hay unidades pendientes en taller.</p>
                </div>
             }
          </div>
       </div>
    </div>
  `
})
export class ServicePanelComponent {
  dataService: DataService = inject(DataService);

  openFailures = computed(() => this.dataService.forkliftFailures().filter(f => f.estatus !== 'Cerrada'));
  
  pendingParts = computed(() => 
     this.openFailures().filter(f => f.estatusRefaccion === 'Pedida' || f.estatusRefaccion === 'Por Recibir').length
  );
  
  criticalCount = computed(() => 
     this.openFailures().filter(f => f.prioridad === 'Alta').length
  );

  async saveLogistics(id: string, po: string, status: any) {
    await this.dataService.updateToyotaLogistics(id, po, status);
  }

  async addNote(id: string, note: string) {
    if(!note) return;
    await this.dataService.addFailureUpdate(id, note, 'Toyota Tech');
  }

  async closeTicket(id: string) {
    if(confirm('¿Confirmar liberación de equipo? Esto lo marcará como "Operativo" y cerrará la orden.')) {
      await this.dataService.closeLiveFailure(id);
    }
  }

  getPriorityBadgeClass(p: string): string {
     if (p === 'Alta') return 'bg-red-50 text-red-600 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-800';
     if (p === 'Media') return 'bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-900/20 dark:text-amber-300 dark:border-amber-800';
     return 'bg-blue-50 text-blue-600 border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-800';
  }
}