
import { Component, ElementRef, ViewChild, effect, inject, computed } from '@angular/core';
import { DataService } from '../../services/data.service';
import { Asset } from '../../types';
import { CommonModule, CurrencyPipe, PercentPipe } from '@angular/common';

declare var Chart: any;

@Component({
  selector: 'app-dashboard',
  standalone: true, 
  imports: [CommonModule, CurrencyPipe, PercentPipe],
  template: `
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <!-- KPI Cards -->
      <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div class="flex justify-between items-start">
          <div>
            <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Disponibilidad</p>
            <h3 class="text-2xl font-bold text-gray-800 mt-1">{{ kpi().availability | number:'1.1-1' }}%</h3>
          </div>
          <div class="p-2 bg-green-50 rounded-lg text-green-600">
            <i class="fas fa-check-circle"></i>
          </div>
        </div>
        <div class="mt-4 h-2 w-full bg-gray-100 rounded-full overflow-hidden">
          <div class="h-full bg-green-500 rounded-full" [style.width.%]="kpi().availability"></div>
        </div>
      </div>

      <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div class="flex justify-between items-start">
          <div>
            <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide">MTTR (Promedio)</p>
            <h3 class="text-2xl font-bold text-gray-800 mt-1">{{ kpi().mttr }} hrs</h3>
          </div>
          <div class="p-2 bg-blue-50 rounded-lg text-blue-600">
            <i class="fas fa-clock"></i>
          </div>
        </div>
        <p class="text-xs text-gray-400 mt-4">Tiempo medio de reparación</p>
      </div>

      <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div class="flex justify-between items-start">
          <div>
            <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Gasto Mensual</p>
            <h3 class="text-2xl font-bold text-gray-800 mt-1">{{ kpi().totalCostMonth | currency }}</h3>
          </div>
          <div class="p-2 bg-purple-50 rounded-lg text-purple-600">
            <i class="fas fa-dollar-sign"></i>
          </div>
        </div>
        <p class="text-xs mt-4" [class.text-red-500]="kpi().totalCostMonth > kpi().budgetMonth" [class.text-green-500]="kpi().totalCostMonth <= kpi().budgetMonth">
          {{ kpi().totalCostMonth > kpi().budgetMonth ? 'Sobre presupuesto' : 'Bajo presupuesto' }}
        </p>
      </div>

      <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div class="flex justify-between items-start">
          <div>
            <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Órdenes Abiertas</p>
            <h3 class="text-2xl font-bold text-gray-800 mt-1">
              {{ openOrdersCount() }}
            </h3>
          </div>
          <div class="p-2 bg-red-50 rounded-lg text-red-600">
            <i class="fas fa-tools"></i>
          </div>
        </div>
        <p class="text-xs text-gray-400 mt-4">Equipos en taller actualmente</p>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      <!-- Charts -->
      <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100 lg:col-span-2">
        <h4 class="text-lg font-bold text-gray-800 mb-4">Pareto de Fallas (Top 5)</h4>
        <div class="relative h-64 w-full">
          <canvas #paretoChart></canvas>
        </div>
      </div>

      <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h4 class="text-lg font-bold text-gray-800 mb-4">Estado de Flota</h4>
        <div class="relative h-64 w-full flex items-center justify-center">
          <canvas #donutChart></canvas>
        </div>
      </div>
    </div>

    <!-- Audit Section (New) -->
    <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div class="flex items-center gap-3 mb-6 pb-4 border-b border-gray-100">
         <i class="fas fa-clipboard-check text-indigo-600 text-xl"></i>
         <h3 class="text-xl font-bold text-gray-800">Estatus de Flota (Auditoría)</h3>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        @for (m of assets(); track m.id) {
          <div 
             class="border-l-4 p-4 rounded-lg shadow-sm border transition hover:shadow-md"
             [class.border-red-500]="m.status.name === 'Taller'"
             [class.bg-red-50]="m.status.name === 'Taller'"
             [class.border-green-500]="m.status.name === 'Operativo'"
             [class.bg-green-50]="m.status.name === 'Operativo'"
             [class.border-yellow-500]="m.status.name === 'Preventivo'"
             [class.bg-yellow-50]="m.status.name === 'Preventivo'"
             [class.border-gray-500]="m.status.name === 'Baja'"
             [class.bg-gray-50]="m.status.name === 'Baja'"
          >
            <div class="flex justify-between items-start mb-2">
              <span class="font-bold text-lg text-gray-800">{{ m.id }}</span>
              <span class="text-[10px] font-bold uppercase px-2 py-1 rounded-full bg-white/50 border border-black/5"
                [class.text-red-700]="m.status.name === 'Taller'"
                [class.text-green-700]="m.status.name === 'Operativo'">
                {{ m.status.name }}
              </span>
            </div>
            
            <p class="text-sm text-gray-600 font-medium">{{ m.brand }} - {{ m.model }}</p>
            
            @if (m.status.name === 'Taller') {
              <div class="mt-3 pt-3 border-t border-red-200/50">
                <p class="text-xs text-red-700 font-bold mb-1">
                   <i class="fas fa-wrench mr-1"></i> {{ m.lastFailure || 'Sin diagnóstico' }}
                </p>
                <p class="text-xs text-gray-500">
                   <i class="fas fa-history mr-1"></i> Días detenido: {{ getDaysStopped(m) }}
                </p>
              </div>
            }
          </div>
        }
      </div>
    </div>
  `
})
export class DashboardComponent {
  private dataService = inject(DataService);
  
  kpi = this.dataService.kpiData;
  reports = this.dataService.reports;
  assets = this.dataService.assets;

  @ViewChild('paretoChart') paretoCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('donutChart') donutCanvas!: ElementRef<HTMLCanvasElement>;

  // Properly computed signal for open orders
  openOrdersCount = computed(() => 
    this.dataService.assets().filter(a => a.status.name === 'Taller').length
  );
  
  constructor() {
    effect(() => {
      // Re-render charts when data changes
      const currentReports = this.reports();
      const currentAssets = this.assets();
      
      // Need timeout to ensure canvas is in DOM
      setTimeout(() => {
        this.initParetoChart(currentReports);
        this.initDonutChart(currentAssets);
      }, 100);
    });
  }

  getDaysStopped(asset: Asset): number {
    if (!asset.statusSince) return 0;
    const start = new Date(asset.statusSince).getTime();
    const now = new Date().getTime();
    return Math.floor((now - start) / (1000 * 3600 * 24));
  }

  initParetoChart(reports: any[]) {
    if (!this.paretoCanvas) return;
    
    // Aggregate failures by type
    const failureCounts: {[key: string]: number} = {};
    reports.forEach(r => {
      failureCounts[r.type] = (failureCounts[r.type] || 0) + 1;
    });

    const labels = Object.keys(failureCounts);
    const data = Object.values(failureCounts);

    // Destroy logic omitted for brevity in snippet, assumes simple lifecycle
    if (Chart.getChart(this.paretoCanvas.nativeElement)) {
        Chart.getChart(this.paretoCanvas.nativeElement).destroy();
    }

    new Chart(this.paretoCanvas.nativeElement, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: '# de Fallas',
          data: data,
          backgroundColor: '#3b82f6',
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: { beginAtZero: true, grid: { display: false } },
          x: { grid: { display: false } }
        }
      }
    });
  }

  initDonutChart(assets: any[]) {
    if (!this.donutCanvas) return;

    const statusCounts = {
      'Operativo': 0,
      'Taller': 0,
      'Preventivo': 0,
      'Baja': 0
    };

    assets.forEach(a => {
      // @ts-ignore
      if (statusCounts[a.status.name] !== undefined) statusCounts[a.status.name]++;
    });

    if (Chart.getChart(this.donutCanvas.nativeElement)) {
        Chart.getChart(this.donutCanvas.nativeElement).destroy();
    }

    new Chart(this.donutCanvas.nativeElement, {
      type: 'doughnut',
      data: {
        labels: Object.keys(statusCounts),
        datasets: [{
          data: Object.values(statusCounts),
          backgroundColor: ['#22c55e', '#ef4444', '#eab308', '#6b7280'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '75%',
        plugins: {
          legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } }
        }
      }
    });
  }
}
