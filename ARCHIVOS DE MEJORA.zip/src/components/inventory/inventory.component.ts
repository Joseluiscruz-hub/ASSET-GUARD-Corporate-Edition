import { Component, inject, computed, signal } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-inventory',
  standalone: true,
  imports: [CommonModule, CurrencyPipe, FormsModule],
  template: `
    <div class="p-6 max-w-7xl mx-auto animate-fade-in">
      <div class="flex justify-between items-center mb-6">
        <div>
          <h2 class="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <i class="fas fa-boxes text-blue-600 dark:text-blue-400"></i> Gestión de Inventario y Refacciones
          </h2>
          <p class="text-slate-500 dark:text-slate-400 text-sm mt-1">Control de stock, costos y alertas de reabastecimiento.</p>
        </div>
        <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 shadow-sm">
          <i class="fas fa-plus"></i> Nueva Refacción
        </button>
      </div>

      <!-- KPI Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <p class="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">Total Refacciones</p>
          <p class="text-3xl font-black text-slate-800 dark:text-white">{{ totalItems() }}</p>
        </div>
        <div class="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <p class="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">Valor del Inventario</p>
          <p class="text-3xl font-black text-blue-600 dark:text-blue-400">{{ totalValue() | currency }}</p>
        </div>
        <div class="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <p class="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">Stock Bajo</p>
          <p class="text-3xl font-black text-red-600 dark:text-red-400">{{ lowStockCount() }}</p>
        </div>
        <div class="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <p class="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">Categorías</p>
          <p class="text-3xl font-black text-emerald-600 dark:text-emerald-400">5</p>
        </div>
      </div>

      <!-- Filters -->
      <div class="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm mb-6 flex gap-4">
        <div class="flex-1 relative">
          <i class="fas fa-search absolute left-3 top-3 text-slate-400"></i>
          <input type="text" [ngModel]="searchTerm()" (ngModelChange)="searchTerm.set($event)" placeholder="Buscar por SKU, nombre o categoría..." class="w-full pl-10 pr-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition">
        </div>
        <select class="border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none">
          <option value="">Todas las Categorías</option>
          <option value="Mecánico">Mecánico</option>
          <option value="Eléctrico">Eléctrico</option>
          <option value="Hidráulico">Hidráulico</option>
          <option value="Consumible">Consumible</option>
        </select>
      </div>

      <!-- Inventory Table -->
      <div class="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse">
            <thead>
              <tr class="bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-700">
                <th class="p-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">SKU</th>
                <th class="p-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Nombre</th>
                <th class="p-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Categoría</th>
                <th class="p-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Stock</th>
                <th class="p-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Costo Unit.</th>
                <th class="p-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Ubicación</th>
                <th class="p-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Acciones</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
              @for (item of filteredInventory(); track item.id) {
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition">
                  <td class="p-4">
                    <span class="font-mono text-xs font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-900 px-2 py-1 rounded">{{ item.sku }}</span>
                  </td>
                  <td class="p-4 font-medium text-slate-800 dark:text-white">{{ item.name }}</td>
                  <td class="p-4">
                    <span class="text-xs font-medium px-2.5 py-1 rounded-full border"
                      [ngClass]="{
                        'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800': item.category === 'Eléctrico',
                        'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-800': item.category === 'Mecánico',
                        'bg-cyan-50 text-cyan-700 border-cyan-200 dark:bg-cyan-900/30 dark:text-cyan-300 dark:border-cyan-800': item.category === 'Hidráulico',
                        'bg-slate-100 text-slate-700 border-slate-300 dark:bg-slate-700 dark:text-slate-300 dark:border-slate-600': item.category === 'Consumible'
                      }">
                      {{ item.category }}
                    </span>
                  </td>
                  <td class="p-4">
                    <div class="flex items-center gap-2">
                      <span class="font-bold" [ngClass]="item.stock <= item.minStock ? 'text-red-600 dark:text-red-400' : 'text-slate-800 dark:text-white'">{{ item.stock }}</span>
                      @if (item.stock <= item.minStock) {
                        <i class="fas fa-exclamation-triangle text-red-500 text-xs" title="Stock bajo"></i>
                      }
                    </div>
                  </td>
                  <td class="p-4 text-slate-600 dark:text-slate-400">{{ item.unitCost | currency }}</td>
                  <td class="p-4 text-sm text-slate-500 dark:text-slate-400"><i class="fas fa-map-marker-alt mr-1"></i> {{ item.location }}</td>
                  <td class="p-4 text-right">
                    <button class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 p-1 mx-1 transition"><i class="fas fa-edit"></i></button>
                    <button class="text-emerald-600 hover:text-emerald-800 dark:text-emerald-400 dark:hover:text-emerald-300 p-1 mx-1 transition" title="Reabastecer"><i class="fas fa-plus-circle"></i></button>
                  </td>
                </tr>
              }
              @if (filteredInventory().length === 0) {
                <tr>
                  <td colspan="7" class="p-8 text-center text-slate-500 dark:text-slate-400">
                    <i class="fas fa-box-open text-4xl mb-3 opacity-50"></i>
                    <p>No se encontraron refacciones.</p>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class InventoryComponent {
  dataService = inject(DataService);
  
  searchTerm = signal('');

  inventory = this.dataService.inventory;

  filteredInventory = computed(() => {
    const term = this.searchTerm().toLowerCase();
    if (!term) return this.inventory();
    return this.inventory().filter(item => 
      item.name.toLowerCase().includes(term) || 
      item.sku.toLowerCase().includes(term) ||
      item.category.toLowerCase().includes(term)
    );
  });

  totalItems = computed(() => this.inventory().length);
  
  totalValue = computed(() => {
    return this.inventory().reduce((acc, item) => acc + (item.stock * item.unitCost), 0);
  });

  lowStockCount = computed(() => {
    return this.inventory().filter(item => item.stock <= item.minStock).length;
  });
}
