
import { Component, input, inject, signal, computed, effect } from '@angular/core';
import { CommonModule, DatePipe, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService } from '../../services/data.service';
import { GeminiService } from '../../services/gemini.service';
import { Asset, FailureReport } from '../../types';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

@Component({
  selector: 'app-asset-detail',
  standalone: true,
  imports: [CommonModule, DatePipe, CurrencyPipe, FormsModule],
  template: `
    @if (asset()) {
      <div class="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden animate-fade-in relative">
        
        <!-- Critical Badge -->
        @if (asset()!.critical) {
           <div class="absolute top-0 right-0 bg-red-600 text-white text-[10px] uppercase font-bold px-3 py-1 rounded-bl-lg z-10">
             Activo Crítico
           </div>
        }

        <!-- Header -->
        <div class="bg-slate-800 text-white p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div class="flex items-center gap-3">
              <h2 class="text-2xl font-bold">{{ asset()!.id }}</h2>
              <span class="px-3 py-1 rounded-full text-xs font-bold" 
                [ngClass]="{
                  'bg-green-500 text-white': asset()!.status.name === 'Operativo',
                  'bg-red-500 text-white': asset()!.status.name === 'Taller',
                  'bg-yellow-500 text-black': asset()!.status.name === 'Preventivo'
                }">
                {{ asset()!.status.name }}
              </span>
            </div>
            <p class="text-slate-300 mt-1">{{ asset()!.brand }} {{ asset()!.model }} | SN: {{ asset()!.serial }}</p>
            <div class="text-xs text-slate-400 mt-1 flex gap-2">
              <span><i class="fas fa-map-marker-alt mr-1"></i>{{ asset()!.location }}</span>
            </div>
          </div>
          <div class="flex flex-wrap gap-2">
            <button (click)="close()" class="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm transition" title="Volver">
              <i class="fas fa-arrow-left"></i>
            </button>
            <button (click)="printReport()" class="px-3 py-2 rounded-lg bg-slate-600 hover:bg-slate-500 text-white text-sm font-medium transition" title="Imprimir">
              <i class="fas fa-print"></i>
            </button>
            <button (click)="exportPdf()" class="px-3 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium transition shadow-lg shadow-rose-900/20">
              <i class="fas fa-file-pdf mr-2"></i> PDF
            </button>
            <button (click)="sendEmail()" class="px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm font-medium transition shadow-lg shadow-sky-900/20">
              <i class="fas fa-envelope mr-2"></i> Correo
            </button>
          </div>
        </div>

        <div class="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <!-- Column 1 & 2: Main Content -->
          <div class="lg:col-span-2 space-y-6">
            
            <!-- Quick Stats -->
            <div class="grid grid-cols-3 gap-4">
               <div class="p-4 bg-gray-50 rounded-lg border border-gray-100 text-center">
                 <div class="text-xs text-gray-500 uppercase">Combustible</div>
                 <div class="font-bold text-gray-800">{{ asset()!.fuelType }}</div>
               </div>
               <div class="p-4 bg-gray-50 rounded-lg border border-gray-100 text-center">
                 <div class="text-xs text-gray-500 uppercase">Adquisición</div>
                 <div class="font-bold text-gray-800">{{ asset()!.acquisitionDate | date:'MM/yyyy' }}</div>
               </div>
               <div class="p-4 bg-gray-50 rounded-lg border border-gray-100 text-center">
                 <div class="text-xs text-gray-500 uppercase">Total Fallas</div>
                 <div class="font-bold text-gray-800">{{ history().length }}</div>
               </div>
            </div>

            <!-- Operations Actions Area -->
            <div class="bg-gray-50 p-6 rounded-xl border border-gray-200">
               <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                 <i class="fas fa-cogs text-gray-400"></i> Gestión Operativa
               </h3>

               @if (asset()!.status.name === 'Operativo') {
                  <!-- Form: Reportar Falla -->
                  <div class="bg-white p-4 rounded-lg border border-red-100 shadow-sm">
                    <h4 class="text-red-700 font-semibold mb-3">Registrar Ingreso a Taller</h4>
                    <div class="flex flex-col gap-3">
                      <select #failType class="w-full p-2 border border-gray-300 rounded text-sm bg-gray-50">
                        <option value="Mecánico">Falla Mecánica</option>
                        <option value="Eléctrico">Falla Eléctrica</option>
                        <option value="Hidráulico">Sistema Hidráulico</option>
                        <option value="Llantas">Llantas / Rodaje</option>
                        <option value="Operador">Daño por Operación</option>
                      </select>
                      <textarea #failDesc class="w-full p-2 border border-gray-300 rounded text-sm bg-gray-50" rows="2" placeholder="Describe la falla detalladamente..."></textarea>
                      <button (click)="reportFailure(failDesc.value, failType.value)" 
                              class="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-2 rounded transition">
                        Confirmar Ingreso
                      </button>
                    </div>
                  </div>
               } @else if (asset()!.status.name === 'Taller') {
                  <!-- Form: Finalizar Reparacion -->
                  <div class="bg-white p-4 rounded-lg border border-green-100 shadow-sm">
                    <h4 class="text-green-700 font-semibold mb-3">Finalizar y Liberar Equipo</h4>
                    <div class="flex flex-col gap-3">
                      <textarea #diagnosis class="w-full p-2 border border-gray-300 rounded text-sm bg-gray-50" rows="2" placeholder="Diagnóstico final y solución..."></textarea>
                      <div class="grid grid-cols-2 gap-3">
                        <input #cost type="number" class="p-2 border border-gray-300 rounded text-sm" placeholder="Costo Refacciones ($)">
                        <input #parts type="text" class="p-2 border border-gray-300 rounded text-sm" placeholder="Refacciones (separar por coma)">
                      </div>
                      <button (click)="finishRepair(diagnosis.value, cost.value, parts.value)" 
                              class="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-2 rounded transition">
                        Liberar Equipo a Operación
                      </button>
                    </div>
                  </div>
               }
            </div>

            <!-- History Table -->
            <div>
              <h3 class="text-lg font-bold text-gray-800 mb-4 border-l-4 border-blue-500 pl-3">Historial Clínico</h3>
              <div class="overflow-x-auto rounded-lg border border-gray-200">
                <table class="w-full text-sm text-left min-w-[800px]">
                  <thead class="bg-gray-50 text-gray-500 font-semibold">
                    <tr>
                      <th class="p-3 whitespace-nowrap">Fecha</th>
                      <th class="p-3">Falla</th>
                      <th class="p-3">Diagnóstico</th>
                      <th class="p-3">Refacciones</th>
                      <th class="p-3">Tipo</th>
                      <th class="p-3 text-right">Costo</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-gray-100">
                    @for (item of history(); track item.id) {
                      <tr class="hover:bg-gray-50 transition"
                          [class.bg-red-50]="!item.exitDate" 
                          [class.border-l-4]="!item.exitDate" 
                          [class.border-red-500]="!item.exitDate">
                        <td class="p-3 text-gray-600 align-top whitespace-nowrap">
                          {{ item.entryDate | date:'shortDate' }}
                          @if (!item.exitDate) {
                             <span class="inline-block px-2 py-0.5 rounded bg-red-100 text-red-600 text-[10px] font-bold mt-1 border border-red-200">
                              ABIERTO
                            </span>
                          }
                        </td>
                        <td class="p-3 text-gray-800 align-top">
                          <div class="font-medium">{{ item.failureDescription }}</div>
                        </td>
                        <td class="p-3 text-gray-600 text-xs align-top max-w-[200px]">
                           {{ item.diagnosis || '-' }}
                        </td>
                        <td class="p-3 text-gray-600 text-xs align-top max-w-[200px]">
                           @if (item.partsUsed && item.partsUsed.length > 0) {
                             <div class="flex flex-wrap gap-1.5">
                               @for (part of item.partsUsed; track $index) {
                                 <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 ring-1 ring-inset ring-blue-700/10">
                                   {{ part }}
                                 </span>
                               }
                             </div>
                           } @else {
                             <span class="text-gray-400 italic text-xs">N/A</span>
                           }
                        </td>
                        <td class="p-3 align-top">
                          <span class="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded whitespace-nowrap">{{ item.type }}</span>
                        </td>
                        <td class="p-3 text-right font-mono text-gray-700 align-top whitespace-nowrap">{{ item.estimatedCost | currency }}</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- Column 3: AI Sidebar -->
          <div class="space-y-6">
            <div class="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl border border-indigo-100">
              <div class="flex items-center gap-2 mb-4">
                <div class="p-2 bg-indigo-600 text-white rounded-lg shadow-sm">
                  <i class="fas fa-robot"></i>
                </div>
                <h3 class="text-lg font-bold text-indigo-900">IA Predictiva</h3>
              </div>

              <p class="text-sm text-indigo-800 mb-4 opacity-80">
                Analiza patrones de falla y obtén recomendaciones preventivas.
              </p>

              @if (aiLoading()) {
                <div class="flex items-center gap-3 text-indigo-600 font-medium animate-pulse">
                  <i class="fas fa-spinner fa-spin"></i> Analizando datos...
                </div>
              } @else if (aiResult()) {
                <div class="prose prose-sm prose-indigo bg-white p-4 rounded-lg shadow-sm border border-indigo-100/50 max-h-96 overflow-y-auto custom-scroll" [innerHTML]="aiResult()"></div>
                <button (click)="runAnalysis()" class="mt-4 w-full py-2 text-xs font-bold text-indigo-600 hover:text-indigo-800 uppercase tracking-wide">
                  Regenerar Análisis
                </button>
              } @else {
                <button (click)="runAnalysis()" class="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium shadow-md shadow-indigo-200 transition flex items-center justify-center gap-2">
                  <i class="fas fa-magic"></i> Ejecutar Diagnóstico
                </button>
              }
            </div>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .animate-fade-in { animation: fadeIn 0.3s ease-out; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
  `]
})
export class AssetDetailComponent {
  assetId = input<string>('');
  
  private dataService = inject(DataService);
  private geminiService = inject(GeminiService);

  asset = computed(() => this.dataService.getAsset(this.assetId()));
  history = computed(() => this.assetId() ? this.dataService.getAssetHistory(this.assetId()) : []);
  
  aiLoading = signal(false);
  aiResult = signal<string | null>(null);

  constructor() {
    effect(() => {
      // Reset AI result when asset changes
      this.assetId();
      this.aiResult.set(null);
    }, { allowSignalWrites: true });
  }

  // --- Actions ---
  
  reportFailure(desc: string, type: any) {
    if (!desc) return alert('Por favor describe la falla.');
    this.dataService.reportFailure(this.assetId(), desc, type);
  }

  finishRepair(diag: string, costStr: string, partsStr: string) {
    if (!diag) return alert('El diagnóstico es requerido.');
    const cost = parseFloat(costStr) || 0;
    const parts = partsStr.split(',').map(p => p.trim()).filter(p => p);
    
    this.dataService.completeRepair(this.assetId(), diag, cost, parts);
  }

  async runAnalysis() {
    const currentAsset = this.asset();
    if (!currentAsset) return;

    this.aiLoading.set(true);
    const result = await this.geminiService.analyzeMaintenanceHistory(currentAsset, this.history());
    this.aiResult.set(result);
    this.aiLoading.set(false);
  }

  exportPdf() {
    const doc = new jsPDF();
    const currentAsset = this.asset();
    if (!currentAsset) return;

    // Header
    doc.setFontSize(20);
    doc.text(`Historial Clínico: ${currentAsset.id}`, 14, 20);
    
    doc.setFontSize(10);
    doc.text(`Marca: ${currentAsset.brand} | Modelo: ${currentAsset.model}`, 14, 28);
    doc.text(`Serie: ${currentAsset.serial} | Estatus: ${currentAsset.status.name}`, 14, 33);
    doc.text(`Generado: ${new Date().toLocaleDateString()}`, 14, 38);

    // Table
    const tableData = this.history().map(row => [
      new Date(row.entryDate).toLocaleDateString(),
      row.failureDescription,
      row.diagnosis || '-',
      (row.partsUsed || []).join(', '),
      `$${row.estimatedCost}`
    ]);

    autoTable(doc, {
      startY: 45,
      head: [['Fecha', 'Falla', 'Diagnóstico', 'Refacciones', 'Costo']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [51, 65, 85] }
    });

    doc.save(`historial_${currentAsset.id}.pdf`);
  }

  sendEmail() {
    const currentAsset = this.asset();
    if (!currentAsset) return;

    const subject = encodeURIComponent(`Seguimiento de Activo ${currentAsset.id} - ${currentAsset.status.name}`);
    const bodyText = `
Hola,

Adjunto el seguimiento para el equipo:
ID: ${currentAsset.id}
Marca: ${currentAsset.brand}
Modelo: ${currentAsset.model}
Serie: ${currentAsset.serial}

Estatus Actual: ${currentAsset.status.name}
Última Falla Registrada: ${currentAsset.lastFailure || 'N/A'}

Favor de revisar el historial en el sistema para más detalles.

Saludos,
AssetGuard System
    `.trim();

    const body = encodeURIComponent(bodyText);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  }

  close() {
    window.dispatchEvent(new CustomEvent('asset-closed'));
  }

  printReport() {
    window.print();
  }
}
