
import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { DataService } from '../../services/data.service';
import { Asset } from '../../types';

@Component({
  selector: 'app-asset-list',
  standalone: true,
  imports: [CommonModule, DatePipe],
  template: `
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="p-6 border-b border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-bold text-gray-800">Torre de Control</h2>
          <p class="text-sm text-gray-500">Monitoreo en tiempo real de la flota</p>
        </div>
        
        <div class="flex gap-2">
          <input 
            type="text" 
            placeholder="Buscar ID o Serie..." 
            class="px-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full md:w-64"
            (input)="updateFilter($event)"
          >
          <button class="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition">
            <i class="fas fa-filter"></i>
          </button>
        </div>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
          <thead>
            <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider">
              <th class="p-4 font-semibold">ID Economico</th>
              <th class="p-4 font-semibold">Equipo</th>
              <th class="p-4 font-semibold">Serie</th>
              <th class="p-4 font-semibold">Estatus</th>
              <th class="p-4 font-semibold">Tiempo en Estatus</th>
              <th class="p-4 font-semibold text-right">Acciones</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-100 text-sm">
            @for (asset of filteredAssets(); track asset.id) {
              <tr 
                class="hover:bg-gray-50 transition cursor-pointer" 
                [class.bg-red-50]="isCriticalDelay(asset)"
                [class.animate-pulse-bg]="isCriticalDelay(asset)"
                [class.border-l-4]="isCriticalDelay(asset)"
                [class.border-red-500]="isCriticalDelay(asset)"
                (click)="selectAsset(asset)"
              >
                <td class="p-4 font-medium text-gray-900">{{ asset.id }}</td>
                <td class="p-4 text-gray-600">
                  <div class="font-medium">{{ asset.brand }}</div>
                  <div class="text-xs">{{ asset.model }}</div>
                </td>
                <td class="p-4 text-gray-500 font-mono">{{ asset.serial }}</td>
                <td class="p-4">
                  <div class="flex items-center gap-2">
                    <span [class]="'px-3 py-1 rounded-full text-xs font-semibold ' + asset.status.color">
                      {{ asset.status.name }}
                    </span>
                    @if (isCriticalDelay(asset)) {
                      <i class="fas fa-exclamation-triangle text-red-500 text-base animate-bounce" title="Atención: Demora Crítica"></i>
                    }
                  </div>
                </td>
                <td class="p-4">
                  <!-- Time Alert Logic: Red text & pulsing icon if Taller > 48h -->
                  <div [class]="'flex items-center ' + getTimeClass(asset)">
                    <i class="fas fa-clock mr-2" [class.animate-pulse]="isCriticalDelay(asset)"></i>
                    {{ getHoursInStatus(asset.statusSince) }} hrs
                  </div>
                  @if (isCriticalDelay(asset)) {
                    <div class="text-[10px] text-red-600 font-bold mt-1 uppercase">
                      ¡Demora Crítica!
                    </div>
                  }
                </td>
                <td class="p-4 text-right">
                  <button class="text-blue-600 hover:text-blue-800 font-medium text-sm" (click)="selectAsset(asset); $event.stopPropagation()">
                    Ver Detalle
                  </button>
                </td>
              </tr>
            } @empty {
              <tr>
                <td colspan="6" class="p-8 text-center text-gray-500">No se encontraron equipos</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    @keyframes pulse-bg {
      0%, 100% { background-color: #fef2f2; }
      50% { background-color: #fee2e2; }
    }
    .animate-pulse-bg {
      animation: pulse-bg 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
  `]
})
export class AssetListComponent {
  private dataService = inject(DataService);
  
  filterText = signal('');
  
  filteredAssets = computed(() => {
    const text = this.filterText().toLowerCase();
    return this.dataService.assets().filter(a => 
      a.id.toLowerCase().includes(text) || 
      a.serial.toLowerCase().includes(text) ||
      a.brand.toLowerCase().includes(text)
    );
  });

  selectAsset(asset: Asset) {
    window.dispatchEvent(new CustomEvent('asset-selected', { detail: asset.id }));
  }

  updateFilter(event: Event) {
    const input = event.target as HTMLInputElement;
    this.filterText.set(input.value);
  }

  getHoursInStatus(dateStr: string): number {
    const start = new Date(dateStr).getTime();
    const now = new Date().getTime();
    return Math.floor((now - start) / (1000 * 60 * 60));
  }

  isCriticalDelay(asset: Asset): boolean {
    if (asset.status.name !== 'Taller') return false;
    const hours = this.getHoursInStatus(asset.statusSince);
    return hours > 48;
  }

  getTimeClass(asset: Asset): string {
    if (this.isCriticalDelay(asset)) {
      return 'text-red-600 font-bold';
    }
    return 'text-gray-600';
  }
}
