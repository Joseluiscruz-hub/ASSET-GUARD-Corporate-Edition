import { Component, inject, computed, signal } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService } from '../../services/data.service';
import { WorkOrder } from '../../types';

@Component({
  selector: 'app-work-orders',
  standalone: true,
  imports: [CommonModule, DatePipe, FormsModule],
  template: `
    <div class="p-6 max-w-[1600px] mx-auto animate-fade-in h-[calc(100vh-80px)] flex flex-col">
      <div class="flex justify-between items-center mb-6">
        <div>
          <h2 class="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <i class="fas fa-tasks text-emerald-600 dark:text-emerald-400"></i> Tablero Kanban de Órdenes de Trabajo
          </h2>
          <p class="text-slate-500 dark:text-slate-400 text-sm mt-1">Gestión visual de tareas de mantenimiento y asignaciones.</p>
        </div>
        <div class="flex gap-3">
          <div class="relative">
            <i class="fas fa-search absolute left-3 top-2.5 text-slate-400"></i>
            <input type="text" [ngModel]="searchTerm()" (ngModelChange)="searchTerm.set($event)" placeholder="Buscar OT..." class="w-64 pl-10 pr-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none transition shadow-sm text-sm">
          </div>
          <button class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 shadow-sm text-sm">
            <i class="fas fa-plus"></i> Nueva OT
          </button>
        </div>
      </div>

      <!-- Kanban Board -->
      <div class="flex-1 flex gap-4 overflow-x-auto pb-4">
        
        <!-- Column: Backlog -->
        <div class="flex-1 min-w-[300px] bg-slate-100 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col max-h-full">
          <div class="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800 rounded-t-xl">
            <h3 class="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <i class="fas fa-inbox text-slate-400"></i> Backlog
            </h3>
            <span class="bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold px-2 py-1 rounded-full">{{ backlogOrders().length }}</span>
          </div>
          <div class="p-3 flex-1 overflow-y-auto space-y-3">
            @for (wo of backlogOrders(); track wo.id) {
              <ng-container *ngTemplateOutlet="woCard; context: { $implicit: wo }"></ng-container>
            }
          </div>
        </div>

        <!-- Column: To Do -->
        <div class="flex-1 min-w-[300px] bg-slate-100 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col max-h-full">
          <div class="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800 rounded-t-xl">
            <h3 class="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <i class="fas fa-clipboard-list text-blue-500"></i> Por Hacer
            </h3>
            <span class="bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 text-xs font-bold px-2 py-1 rounded-full">{{ todoOrders().length }}</span>
          </div>
          <div class="p-3 flex-1 overflow-y-auto space-y-3">
            @for (wo of todoOrders(); track wo.id) {
              <ng-container *ngTemplateOutlet="woCard; context: { $implicit: wo }"></ng-container>
            }
          </div>
        </div>

        <!-- Column: In Progress -->
        <div class="flex-1 min-w-[300px] bg-slate-100 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col max-h-full">
          <div class="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800 rounded-t-xl">
            <h3 class="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <i class="fas fa-tools text-amber-500"></i> En Proceso
            </h3>
            <span class="bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 text-xs font-bold px-2 py-1 rounded-full">{{ inProgressOrders().length }}</span>
          </div>
          <div class="p-3 flex-1 overflow-y-auto space-y-3">
            @for (wo of inProgressOrders(); track wo.id) {
              <ng-container *ngTemplateOutlet="woCard; context: { $implicit: wo }"></ng-container>
            }
          </div>
        </div>

        <!-- Column: Review -->
        <div class="flex-1 min-w-[300px] bg-slate-100 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col max-h-full">
          <div class="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800 rounded-t-xl">
            <h3 class="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <i class="fas fa-search text-purple-500"></i> Revisión
            </h3>
            <span class="bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 text-xs font-bold px-2 py-1 rounded-full">{{ reviewOrders().length }}</span>
          </div>
          <div class="p-3 flex-1 overflow-y-auto space-y-3">
            @for (wo of reviewOrders(); track wo.id) {
              <ng-container *ngTemplateOutlet="woCard; context: { $implicit: wo }"></ng-container>
            }
          </div>
        </div>

      </div>
    </div>

    <!-- Reusable Card Template -->
    <ng-template #woCard let-wo>
      <div class="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700 cursor-grab hover:shadow-md transition group">
        <div class="flex justify-between items-start mb-2">
          <span class="text-xs font-mono font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-900 px-2 py-1 rounded">{{ wo.id }}</span>
          <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full border"
            [ngClass]="{
              'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-800': wo.priority === 'Urgente',
              'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-800': wo.priority === 'Alta',
              'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-800': wo.priority === 'Media',
              'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-800': wo.priority === 'Baja'
            }">
            {{ wo.priority }}
          </span>
        </div>
        <h4 class="font-bold text-slate-800 dark:text-white text-sm mb-1 line-clamp-2">{{ wo.title }}</h4>
        <p class="text-xs text-slate-500 dark:text-slate-400 mb-3 line-clamp-2">{{ wo.description }}</p>
        
        <div class="flex items-center gap-2 mb-3">
          <span class="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[10px] px-2 py-1 rounded flex items-center gap-1">
            <i class="fas fa-truck-loading"></i> Eq: {{ wo.assetId }}
          </span>
          <span class="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[10px] px-2 py-1 rounded flex items-center gap-1">
            <i class="far fa-clock"></i> {{ wo.estimatedHours }}h
          </span>
        </div>

        <div class="flex justify-between items-center pt-3 border-t border-slate-100 dark:border-slate-700">
          <div class="flex items-center gap-2">
            @if (wo.assignedTo) {
              <div class="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800" title="Asignado a: {{ wo.assignedTo }}">
                {{ wo.assignedTo.charAt(0) }}
              </div>
            } @else {
              <div class="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-400 text-xs border border-slate-200 dark:border-slate-600 border-dashed" title="Sin asignar">
                <i class="fas fa-user-plus"></i>
              </div>
            }
          </div>
          <div class="text-[10px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1" [ngClass]="{'text-red-500 dark:text-red-400': isOverdue(wo.dueDate)}">
            <i class="far fa-calendar-alt"></i> {{ wo.dueDate | date:'dd MMM' }}
          </div>
        </div>
      </div>
    </ng-template>
  `
})
export class WorkOrdersComponent {
  dataService = inject(DataService);
  searchTerm = signal('');

  workOrders = this.dataService.workOrders;

  filteredOrders = computed(() => {
    const term = this.searchTerm().toLowerCase();
    if (!term) return this.workOrders();
    return this.workOrders().filter(wo => 
      wo.title.toLowerCase().includes(term) || 
      wo.id.toLowerCase().includes(term) ||
      wo.assetId.toLowerCase().includes(term)
    );
  });

  backlogOrders = computed(() => this.filteredOrders().filter(wo => wo.status === 'Backlog'));
  todoOrders = computed(() => this.filteredOrders().filter(wo => wo.status === 'To Do'));
  inProgressOrders = computed(() => this.filteredOrders().filter(wo => wo.status === 'In Progress'));
  reviewOrders = computed(() => this.filteredOrders().filter(wo => wo.status === 'Review'));

  isOverdue(dateStr: string): boolean {
    return new Date(dateStr) < new Date();
  }
}
